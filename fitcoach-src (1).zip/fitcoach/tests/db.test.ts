import { describe, it, expect, beforeEach } from 'vitest';
import { freshDb } from './helpers';
import * as repo from '../src/db/repos';
import { migrateAndSeed, getSetting } from '../src/db';
import { EXERCISES } from '../src/data/exercises';
import { FOODS } from '../src/data/foods';

describe('database', () => {
  beforeEach(async () => {
    await freshDb();
  });

  it('applies migrations and seeds reference content once', async () => {
    expect(await getSetting('schema_version')).toBe('1');
    expect((await repo.listExercises()).length).toBe(EXERCISES.length);
    expect((await repo.searchFoods('roti', false)).length).toBeGreaterThan(0);
    expect(FOODS.length).toBeGreaterThan(100);
  });

  it('profile round-trips and logs weight as a measurement', async () => {
    const p = await repo.saveProfile({ name: 'Chirag', heightCm: 174, weightKg: 85, equipment: ['barbell', 'dumbbell'], restrictions: ['knee'] });
    expect(p.weightKg).toBe(85);
    const again = await repo.getProfile();
    expect(again.equipment).toEqual(['barbell', 'dumbbell']);
    expect(again.restrictions).toEqual(['knee']);
    const w = await repo.listMeasurements('weight');
    expect(w[0].value).toBe(85);
  });

  it('goal changes keep history (only one active)', async () => {
    await repo.setGoal('lean', null, null);
    await repo.setGoal('strength', 'endurance', null);
    const g = await repo.getActiveGoal();
    expect(g?.primaryGoal).toBe('strength');
    expect(g?.secondaryGoal).toBe('endurance');
  });

  it('hydration: add, edit, delete, undo, daily totals by local date', async () => {
    const a = await repo.addHydration(250, new Date(2026, 9, 29, 23, 50));
    const b = await repo.addHydration(500, new Date(2026, 9, 30, 0, 10));
    expect(a.localDate).toBe('2026-10-29');
    expect(b.localDate).toBe('2026-10-30');
    await repo.updateHydration(a.id, 300);
    let totals = await repo.hydrationDailyTotals('2026-10-29', '2026-10-30');
    expect(totals).toEqual([{ date: '2026-10-29', ml: 300 }, { date: '2026-10-30', ml: 500 }]);
    await repo.deleteHydration(b.id);
    totals = await repo.hydrationDailyTotals('2026-10-29', '2026-10-30');
    expect(totals).toEqual([{ date: '2026-10-29', ml: 300 }]);
    await repo.undeleteHydration(b.id);
    totals = await repo.hydrationDailyTotals('2026-10-29', '2026-10-30');
    expect(totals.length).toBe(2);
  });

  it('nutrition entries and totals', async () => {
    const e = await repo.addNutritionEntry({ meal: 'lunch', foodId: 'roti', foodName: 'Roti', grams: 80, kcal: 240, protein: 7, carbs: 46, fat: 3, fibre: 5, source: 'database', localDate: '2026-10-29' });
    await repo.updateNutritionEntry({ ...e, grams: 40, kcal: 120, protein: 3.5 });
    const list = await repo.listNutrition('2026-10-29');
    expect(list[0].kcal).toBe(120);
    const totals = await repo.nutritionDailyTotals('2026-10-29', '2026-10-29');
    expect(totals[0].kcal).toBe(120);
  });

  it('reminders are created with defaults and can be saved', async () => {
    const list = await repo.listReminders();
    expect(list.length).toBe(repo.DEFAULT_REMINDERS.length);
    const water = list.find((r) => r.type === 'water')!;
    await repo.saveReminder({ ...water, enabled: true, intervalMinutes: 60 });
    const again = (await repo.listReminders()).find((r) => r.type === 'water')!;
    expect(again.enabled).toBe(true);
    expect(again.intervalMinutes).toBe(60);
  });

  it('delete all user data keeps reference content', async () => {
    await repo.saveProfile({ name: 'X' });
    await repo.addHydration(100);
    await repo.deleteAllUserData();
    expect((await repo.getProfile()).name).toBeNull();
    expect((await repo.listExercises()).length).toBe(EXERCISES.length);
    expect(await getSetting('schema_version')).toBe('1');
  });

  it('re-running migrateAndSeed is idempotent', async () => {
    const d = await freshDb();
    await migrateAndSeed(d);
    expect((await repo.listExercises()).length).toBe(EXERCISES.length);
  });
});
