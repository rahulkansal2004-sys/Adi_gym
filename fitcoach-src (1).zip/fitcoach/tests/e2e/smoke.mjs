// End-to-end smoke test of the web build (sql.js preview) with Playwright.
// Run: npm run build && node tests/e2e/smoke.mjs
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_PKG ?? 'playwright');
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';

const BASE = 'http://localhost:4173';
const OUT = 'tests/e2e/out';
fs.mkdirSync(OUT, { recursive: true });

// Serve dist/ from this process (SPA with hash routes, so only static files are needed).
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.wasm': 'application/wasm', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  let file = path.join('dist', url === '/' ? 'index.html' : url);
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = 'dist/index.html';
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] ?? 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});
await new Promise((r) => server.listen(4173, r));

const results = [];
const LOG = `${OUT}/log.txt`; fs.writeFileSync(LOG, '');
const log = (...a) => { const line = a.join(' '); console.log(line); fs.appendFileSync(LOG, line + '\n'); };
const step = async (name, fn) => {
  try { await fn(); results.push({ name, status: 'pass' }); log('PASS', name); }
  catch (e) { results.push({ name, status: 'fail', error: String(e.message).slice(0, 300) }); log('FAIL', name, e.message); }
};

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
page.setDefaultTimeout(8000);
log('browser ready');
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
const shot = (n) => page.screenshot({ path: `${OUT}/${n}.png` });

await step('app boots and shows onboarding', async () => {
  await page.goto(BASE + '/#/');
  await page.getByRole('button', { name: 'Get started' }).waitFor({ timeout: 20000 });
  await shot('01-welcome');
});

await step('onboarding: profile, goal, training, health', async () => {
  await page.getByRole('button', { name: 'Get started' }).click();
  await page.getByLabel('Name (optional)').fill('Chirag');
  await page.getByLabel('Date of birth', { exact: false }).fill('1998-03-14');
  await page.getByLabel('Height (cm)').fill('174');
  await page.getByLabel('Weight (kg)').fill('85');
  await page.getByRole('button', { name: 'Male', exact: true }).click();
  await page.getByRole('button', { name: 'Intermediate' }).click();
  await shot('02-profile');
  await page.getByRole('button', { name: 'Next' }).click();
  await page.getByRole('button', { name: /Lean and defined/ }).click();
  await page.getByRole('button', { name: /Strength development/ }).click();
  await shot('03-goal');
  await page.getByRole('button', { name: 'Next' }).click();
  await page.getByRole('button', { name: '4', exact: true }).click();
  await page.getByRole('button', { name: '60 min' }).click();
  await page.getByRole('button', { name: 'Full gym' }).click();
  await shot('04-training');
  await page.getByRole('button', { name: 'Next' }).click();
  await page.getByRole('button', { name: 'knee' }).click();
  await shot('05-health');
  await page.getByRole('button', { name: 'Build my programme' }).click();
  await page.getByRole('button', { name: 'Go to home' }).waitFor({ timeout: 20000 });
  await shot('06-done');
  await page.getByRole('button', { name: 'Go to home' }).click();
});

await step('home shows today\'s workout and water card', async () => {
  await page.getByText("Let's build a stronger you").waitFor();
  await page.getByRole('button', { name: 'Preview and start' }).waitFor();
  await page.getByText('Water').waitFor();
  await shot('07-home');
});

await step('workout preview lists exercises with no knee-loading ones', async () => {
  await page.getByRole('button', { name: 'Preview and start' }).click();
  await page.getByRole('button', { name: 'Start workout' }).waitFor();
  const items = await page.locator('ol li').count();
  if (items < 4) throw new Error('expected at least 4 exercises, got ' + items);
  const text = await page.locator('ol').innerText();
  if (/Back squat|Leg press|Lunge/i.test(text)) throw new Error('knee-loading exercise present: ' + text);
  await shot('08-preview');
});

await step('shorter session sheet explains cuts', async () => {
  await page.getByRole('button', { name: 'Less time?' }).click();
  await page.getByRole('button', { name: '30 min' }).click();
  await page.getByText(/Result: about/).waitFor();
  await shot('09-shorten');
  await page.getByRole('button', { name: 'Close' }).click();
});

await step('start workout, log sets, rest timer, finish', async () => {
  await page.getByRole('button', { name: 'Start workout' }).click();
  await page.getByRole('button', { name: /Complete set 1/ }).waitFor();
  await shot('10-session');
  await page.getByLabel('Increase weight').click(); // 0 -> 2.5 (no history)
  await page.getByLabel('Increase weight').click();
  await page.getByRole('button', { name: /Complete set 1/ }).click();
  await page.getByText('Next set when it ends').waitFor();
  await shot('11-rest');
  await page.getByRole('button', { name: 'Skip rest' }).click();
  await page.getByRole('button', { name: /Complete set 2/ }).click();
  await page.getByRole('button', { name: 'Skip rest' }).click();
  await page.getByRole('button', { name: /Complete set 3/ }).click();
});

await step('session survives reload (resume)', async () => {
  await page.waitForTimeout(600); // web preview persists to IndexedDB on a short debounce; native SQLite writes immediately
  await page.reload();
  await page.getByRole('button', { name: /Next exercise|Complete set|Finish workout/ }).waitFor({ timeout: 15000 });
  const txt = await page.locator('body').innerText();
  if (!/Next exercise/.test(txt)) throw new Error('logged sets were not restored after reload: ' + txt.slice(0, 160));
  await shot('12-resumed');
});

await step('substitute an exercise', async () => {
  await page.getByRole('button', { name: 'Swap' }).click();
  await page.getByRole('button', { name: 'equipment' }).click();
  const first = page.locator('.sheet .card').first();
  await first.waitFor();
  await shot('13-swap');
  await first.click();
  await page.getByText(/Swapped to/).waitFor();
});

await step('pain report escalates red flags', async () => {
  await page.getByRole('button', { name: 'Report pain or discomfort' }).click();
  await page.getByLabel('Describe the symptom').fill('chest pain and dizzy');
  await page.getByRole('button', { name: 'Assess' }).click();
  await page.getByText('Stop and seek urgent care').waitFor();
  await shot('14-redflag');
  await page.getByRole('button', { name: 'Close' }).click();
});

await step('finish early records partial session and summary', async () => {
  await page.getByRole('button', { name: 'Finish early' }).click();
  await page.getByRole('button', { name: '8', exact: true }).click();
  await page.getByRole('button', { name: 'Save workout' }).click();
  await page.getByText(/Workout logged/).waitFor({ timeout: 15000 });
  const body = await page.locator('body').innerText();
  if (!/3 \/ \d+/.test(body)) throw new Error('expected "3 / N sets done" in summary: ' + body.slice(0, 200));
  await shot('15-summary');
});

await step('hydration add/edit/delete/undo', async () => {
  await page.goto(BASE + '/#/hydration');
  await page.getByRole('button', { name: '250 ml' }).click();
  await page.getByRole('button', { name: '500 ml' }).click();
  await page.getByText('0.8 L').waitFor();
  await page.getByLabel('Delete entry').first().click();
  await page.getByText('0.5 L').waitFor();
  await page.getByRole('button', { name: 'Undo' }).click();
  await page.getByText('0.8 L').waitFor();
  await shot('16-hydration');
});

await step('nutrition search and add roti', async () => {
  await page.goto(BASE + '/#/nutrition');
  await page.getByRole('button', { name: 'Add food' }).click();
  await page.getByLabel('Search foods').fill('roti');
  await page.locator('.sheet .card').first().click();
  await page.getByRole('button', { name: 'Add to breakfast', exact: true }).click();
  await page.getByText(/Added/).waitFor();
  await shot('17-nutrition');
});

await step('measurements, progress chart, PRs', async () => {
  await page.goto(BASE + '/#/measurements');
  await page.getByRole('button', { name: 'Waist' }).click();
  await page.getByLabel('Value (cm)').fill('86');
  await page.getByRole('button', { name: 'Save measurement' }).click();
  await page.getByText('Waist: 86 cm').waitFor();
  await page.goto(BASE + '/#/progress');
  await page.getByText('Body weight').waitFor();
  await shot('18-progress');
  await page.getByRole('tab', { name: 'Strength' }).click();
  await page.getByText('Personal records').waitFor();
  await shot('19-strength');
});

await step('weekly review renders from data and recovery check-in saves', async () => {
  await page.goto(BASE + '/#/recovery');
  await page.getByLabel('Sleep last night (hours)').fill('7');
  await page.getByRole('button', { name: 'Save today\'s check-in' }).click();
  await page.getByText('Recovery check-in saved').waitFor();
  await page.goto(BASE + '/#/review');
  await page.getByText('Recommendations', { exact: true }).waitFor();
  await shot('20-review');
});

await step('AI coach falls back gracefully when off', async () => {
  await page.goto(BASE + '/#/coach');
  await page.getByText('AI coaching is off').waitFor();
  await page.getByLabel('Message the coach').fill('How did my workout go?');
  await page.getByLabel('Send').click();
  await page.getByText(/unavailable right now/).waitFor();
  await shot('21-coach');
});

await step('reminders, devices, privacy, improve screens render', async () => {
  await page.goto(BASE + '/#/reminders');
  await page.getByText('Quiet hours').waitFor();
  await shot('22-reminders');
  await page.goto(BASE + '/#/devices');
  await page.getByText('Android Health Connect').waitFor();
  await shot('23-devices');
  await page.goto(BASE + '/#/privacy');
  await page.getByText('Where your data lives').waitFor();
  await shot('24-privacy');
  await page.goto(BASE + '/#/improve');
  await page.getByLabel('Title').fill('Dark mode');
  await page.getByLabel('Description').fill('Please add a dark theme');
  await page.getByRole('button', { name: 'Submit request' }).click();
  await page.getByText('submitted').first().waitFor();
  await shot('25-improve');
});

await step('no uncaught page errors', async () => {
  const real = errors.filter((e) => !/favicon|sql-wasm|Download the React DevTools/i.test(e));
  if (real.length) throw new Error(real.join(' | '));
});

await browser.close();
server.close();
fs.writeFileSync(`${OUT}/results.json`, JSON.stringify(results, null, 2));
const failed = results.filter((r) => r.status === 'fail').length;
console.log(`\n${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);
