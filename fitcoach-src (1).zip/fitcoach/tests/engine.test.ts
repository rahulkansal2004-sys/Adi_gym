import { describe, it, expect } from 'vitest';
import { EXERCISES } from '../src/data/exercises';
import { generateProgramme, isAllowed, estimateMinutes } from '../src/engine/programme';
import { suggestLoad, detectPersonalRecords, estimateOneRm } from '../src/engine/progression';
import { suggestSubstitutes, assessSymptom } from '../src/engine/substitution';
import { rescheduleForward, skipMissed, shortenWorkout, missedWorkouts } from '../src/engine/schedule';
import { buildWeeklyReview } from '../src/engine/review';
import { calorieTarget, hydrationTargetMl } from '../src/engine/targets';
import type { Profile, SetLog } from '../src/db/types';

const base: Profile = {
  name: 'T', dob: '1998-03-14', sex: 'male', heightCm: 174, weightKg: 85, targetWeightKg: null, waistCm: null,
  experience: 'intermediate', activityLevel: 'light', daysPerWeek: 4, sessionMinutes: 60,
  equipment: ['barbell', 'dumbbell', 'cable', 'machine', 'bench', 'pull-up-bar', 'cardio-machine'], location: 'gym', diet: 'vegetarian',
  restrictions: [], restrictionNotes: null, restrictionsConfirmedAt: null, excludeGluteIsolation: false, sleepHours: 7,
  unitsWeight: 'kg', unitsLength: 'cm', unitsVolume: 'ml', timezone: null, nutritionEnabled: true, onboardingComplete: true,
};

const exById = new Map(EXERCISES.map((e) => [e.id, e]));

describe('programme generator', () => {
  it('builds a 12-week, 4-day upper/lower block with balanced patterns', () => {
    const r = generateProgramme({ profile: base, goal: 'lean', exercises: EXERCISES, startDate: '2026-11-02' });
    expect(r.programme.template).toBe('upper-lower-4');
    expect(r.workouts.length).toBe(48);
    expect(r.workouts[0].scheduledDate).toBe('2026-11-02'); // Monday
    const dates = new Set(r.workouts.map((w) => w.scheduledDate));
    expect(dates.size).toBe(48); // never two sessions on a day
    const w1 = r.workouts.slice(0, 4);
    const patterns = new Set(w1.flatMap((w) => w.exercises.map((e) => exById.get(e.exerciseId)!.movementPattern)));
    for (const p of ['horizontal-push', 'horizontal-pull', 'vertical-push', 'vertical-pull', 'squat', 'hinge']) expect(patterns.has(p as never)).toBe(true);
    for (const w of r.workouts) expect(w.estimatedMinutes).toBeLessThanOrEqual(65);
    expect(r.workouts.find((w) => w.week === 4)!.name).toContain('lighter');
  });

  it('bodyweight-only beginner still gets every main pattern, within 30 minutes', () => {
    const p: Profile = { ...base, experience: 'new', equipment: ['bodyweight'], daysPerWeek: 3, sessionMinutes: 30 };
    const r = generateProgramme({ profile: p, goal: 'general-health', exercises: EXERCISES, startDate: '2026-11-02' });
    expect(r.workouts.length).toBe(36);
    for (const w of r.workouts) {
      expect(w.estimatedMinutes).toBeLessThanOrEqual(35);
      for (const e of w.exercises) {
        const ex = exById.get(e.exerciseId)!;
        expect(ex.equipment.every((q) => q === 'bodyweight')).toBe(true);
        expect(ex.difficulty).not.toBe('advanced');
      }
    }
    expect(r.warnings.filter((w) => w.includes('add equipment or adjust restrictions')).length).toBe(0);
    // every day still has a pull movement (horizontal fallback when no bar/band for vertical pulls)
    for (const w of r.workouts.slice(0, 3)) {
      expect(w.exercises.some((e) => exById.get(e.exerciseId)!.movementPattern.endsWith('pull'))).toBe(true);
    }
  });

  it('respects restrictions and the glute-isolation exclusion', () => {
    const p: Profile = { ...base, restrictions: ['knee'], excludeGluteIsolation: true, daysPerWeek: 5 };
    const r = generateProgramme({ profile: p, goal: 'muscle-gain', exercises: EXERCISES, startDate: '2026-11-02' });
    for (const w of r.workouts) for (const e of w.exercises) {
      const ex = exById.get(e.exerciseId)!;
      expect(ex.contraindications.includes('knee')).toBe(false);
      expect(ex.isGluteIsolation ?? false).toBe(false);
    }
    expect(r.workouts.filter((w) => w.week === 1).length).toBe(5);
  });

  it('warns about six days for beginners but still builds', () => {
    const r = generateProgramme({ profile: { ...base, experience: 'beginner-some', daysPerWeek: 6 }, goal: 'muscular', exercises: EXERCISES, startDate: '2026-11-02' });
    expect(r.warnings.some((w) => w.includes('Six days'))).toBe(true);
    expect(r.workouts.length).toBe(72);
  });

  it('strength goal uses low reps and long rests on main lifts', () => {
    const r = generateProgramme({ profile: base, goal: 'strength', exercises: EXERCISES, startDate: '2026-11-02' });
    const main = r.workouts[0].exercises.find((e) => e.role === 'main')!;
    expect(main.repMax).toBeLessThanOrEqual(6);
    expect(main.restSeconds).toBeGreaterThanOrEqual(150);
  });

  it('isAllowed filters equipment and difficulty', () => {
    expect(isAllowed(exById.get('barbell-back-squat')!, { ...base, equipment: ['dumbbell'] })).toBe(false);
    expect(isAllowed(exById.get('pull-up')!, { ...base, experience: 'new' })).toBe(false);
    expect(isAllowed(exById.get('push-up')!, { ...base, equipment: [] })).toBe(true);
  });
});

function set(i: number, w: number, reps: number, extra: Partial<SetLog> = {}): SetLog {
  return { id: 's' + i + w + reps + Math.random(), exerciseLogId: 'l', sessionId: 'x', exerciseId: 'barbell-bench-press', setIndex: i, weightKg: w, reps, completed: true, rpe: null, loggedAt: '2026-10-2' + i + 'T10:00:00Z', ...extra };
}

describe('progression', () => {
  const bench = exById.get('barbell-bench-press')!;
  it('does not increase after a single completed session unless all sets hit the top', () => {
    const r = suggestLoad(bench, 8, 12, [set(0, 60, 10), set(1, 60, 10), set(2, 60, 9)], [], null, null);
    expect(r.change).toBe('hold');
    expect(r.kg).toBe(60);
  });
  it('increases by the smallest plate jump when every set reaches the top with normal effort', () => {
    const r = suggestLoad(bench, 8, 12, [set(0, 60, 12), set(1, 60, 12), set(2, 60, 12)], [], 7, 2);
    expect(r).toMatchObject({ change: 'increase', kg: 62.5 });
    const squat = exById.get('barbell-back-squat')!;
    expect(suggestLoad(squat, 6, 10, [set(0, 80, 10), set(1, 80, 10), set(2, 80, 10)], [], null, null).kg).toBe(85);
  });
  it('holds when reps were reached but effort or soreness was high', () => {
    const r = suggestLoad(bench, 8, 12, [set(0, 60, 12), set(1, 60, 12), set(2, 60, 12)], [], 9, 2);
    expect(r.change).toBe('hold');
  });
  it('decreases only after two sessions mostly below the minimum', () => {
    const last = [set(0, 70, 6), set(1, 70, 5), set(2, 70, 5)];
    expect(suggestLoad(bench, 8, 12, last, [], null, null).change).toBe('hold');
    const prev = [set(0, 70, 7), set(1, 70, 6), set(2, 70, 5)];
    const r = suggestLoad(bench, 8, 12, last, prev, null, null);
    expect(r.change).toBe('decrease');
    expect(r.kg).toBeLessThan(70);
  });
  it('bodyweight exercises progress via variation/sets, never kg', () => {
    const r = suggestLoad(exById.get('push-up')!, 8, 12, [set(0, 0, 12), set(1, 0, 12)], [], null, null);
    expect(r.kg).toBeNull();
    expect(r.change).toBe('increase');
  });
  it('estimates 1RM only in 1–12 rep band', () => {
    expect(estimateOneRm(60, 10)).toBe(80);
    expect(estimateOneRm(60, 15)).toBeNull();
  });
  it('detects heaviest, best e1RM and most-reps PRs without duplicates', () => {
    const existing = [{ id: 'p', exerciseId: 'barbell-bench-press', type: 'heaviest' as const, weightKg: 60, reps: 10, value: 60, setLogId: 's', achievedAt: '2026-10-01T00:00:00Z' },
      { id: 'q', exerciseId: 'barbell-bench-press', type: 'most-reps-at-weight' as const, weightKg: 60, reps: 10, value: 10, setLogId: 's', achievedAt: '2026-10-01T00:00:00Z' }];
    const prs = detectPersonalRecords('barbell-bench-press', [set(0, 62.5, 8), set(1, 60, 11)], existing);
    const types = prs.map((p) => p.type).sort();
    expect(types).toEqual(['best-e1rm', 'heaviest', 'most-reps-at-weight']);
    expect(prs.find((p) => p.type === 'heaviest')!.value).toBe(62.5);
    expect(prs.find((p) => p.type === 'most-reps-at-weight')!.reps).toBe(11);
    expect(detectPersonalRecords('barbell-bench-press', [set(0, 55, 8)], [...existing, ...prs]).length).toBe(0);
  });
});

describe('substitution and safety', () => {
  it('suggests same-pattern alternatives that fit equipment', () => {
    const subs = suggestSubstitutes(exById.get('barbell-bench-press')!, 'equipment', { ...base, equipment: ['dumbbell', 'bench'] }, EXERCISES);
    expect(subs.length).toBeGreaterThan(0);
    for (const s of subs) {
      expect(s.exercise.movementPattern).toBe('horizontal-push');
      expect(s.exercise.equipment.every((q) => ['dumbbell', 'bench', 'bodyweight'].includes(q))).toBe(true);
    }
  });
  it('never suggests an exercise that conflicts with a reported area', () => {
    const subs = suggestSubstitutes(exById.get('barbell-back-squat')!, 'discomfort', base, EXERCISES, ['knee']);
    for (const s of subs) expect(s.exercise.contraindications.includes('knee')).toBe(false);
  });
  it('escalates red-flag symptoms instead of substituting', () => {
    expect(assessSymptom('I have chest pain and feel faint', null).level).toBe('emergency');
    expect(assessSymptom('felt a sharp pop in my knee', 'knee').level).toBe('stop');
    expect(assessSymptom('mild ache in shoulder', 'shoulder').level).toBe('modify');
  });
});

describe('scheduling', () => {
  const r = generateProgramme({ profile: base, goal: 'lean', exercises: EXERCISES, startDate: '2026-11-02' });
  it('reschedules missed sessions forward without doubling a day', () => {
    const today = '2026-11-05'; // Thu: Mon 2 and Tue 3 missed
    const missed = missedWorkouts(r.workouts, today);
    expect(missed.length).toBe(2);
    const plan = rescheduleForward(r.workouts, [1, 2, 4, 5], today);
    expect(plan.substantial).toBe(true);
    const first = plan.changes.find((c) => c.id === missed[0].id)!;
    expect(first.to).toBe('2026-11-05');
    const targets = plan.changes.map((c) => c.to);
    expect(new Set(targets).size).toBe(targets.length);
  });
  it('skip keeps dates', () => {
    const plan = skipMissed(r.workouts, '2026-11-05');
    expect(plan.skipped.length).toBe(2);
    expect(plan.changes.length).toBe(0);
  });
  it('shortening keeps main lifts and warm-up and explains cuts', () => {
    const w = r.workouts[0];
    const short = shortenWorkout(w.exercises, 30, (id) => exById.get(id)!.name);
    expect(short.minutes).toBeLessThanOrEqual(32);
    expect(short.exercises.some((e) => e.role === 'main')).toBe(true);
    expect(short.removed.length + short.reducedSets.length).toBeGreaterThan(0);
    expect(estimateMinutes(short.exercises)).toBe(short.minutes);
  });
});

describe('weekly review and targets', () => {
  it('summarises adherence, strength trend and recommends holding when no top-of-range', () => {
    const r = generateProgramme({ profile: base, goal: 'lean', exercises: EXERCISES, startDate: '2026-11-02' });
    const planned = r.workouts.slice(0, 4).map((w, i) => ({ ...w, status: i < 3 ? ('done' as const) : ('planned' as const) }));
    const rev = buildWeeklyReview({
      weekStart: '2026-11-02', weekEnd: '2026-11-08', planned, sessions: [], sets: [set(0, 62.5, 8)], previousSets: [set(0, 60, 8)],
      recovery: [], hydration: [{ date: '2026-11-02', ml: 2600 }, { date: '2026-11-03', ml: 1500 }, { date: '2026-11-04', ml: 1200 }, { date: '2026-11-05', ml: 1000 }],
      hydrationTargetMl: 2500, nutrition: null, measurements: [], exercises: exById,
    });
    expect(rev.adherence).toEqual({ planned: 4, completed: 3, partial: 0 });
    expect(rev.strength[0].trend).toBe('up');
    expect(rev.recommendations.some((x) => x.action === 'progress')).toBe(true);
    expect(rev.improvements.some((x) => x.includes('Water'))).toBe(true);
    expect(rev.dataGaps.length).toBeGreaterThan(0);
  });
  it('calorie and hydration targets are sane and explained', () => {
    const t = calorieTarget(base, 'lean')!;
    expect(t.kcal).toBeGreaterThan(1800);
    expect(t.kcal).toBeLessThan(2600);
    expect(t.protein).toBe(153);
    expect(hydrationTargetMl(base).ml).toBe(3000);
    expect(calorieTarget({ ...base, weightKg: null }, 'lean')).toBeNull();
  });
});
