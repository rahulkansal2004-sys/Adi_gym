# Feature completion matrix

Status key: **Done** = implemented and covered by automated tests or the e2e run · **Done (untested on device)** =
implemented, compiles, but needs the phone to exercise · **Partial** · **Not done**.

| # | Brief section | Status | Notes |
|---|---|---|---|
| 1 | Onboarding and profile | Done | 5 steps, skippable optionals, edit later (Profile › sections). Units stored metric; imperial display not implemented (Partial). |
| 2 | Physique / fitness goal selection | Done | 10 goals, primary + optional secondary, practical blurbs, no appearance promises. Goal change keeps history and asks before rebuilding. |
| 3 | Exercise library | Done | 92 exercises with setup, execution, breathing, dose, mistakes, safety, variations, substitutions, contraindications. **No demo media** (none fabricated; placeholder states source/review status). |
| 4 | Adaptive programmes | Done | 2–6 day templates (full body, upper/lower, hybrid, PPL), goal rep schemes, experience volume, equipment/restriction filters, glute-isolation opt-out, time fitting, deload weeks 4/8/12, 12-week block, next-block rebuild. |
| 5 | Guided workouts with set logging | Done | One exercise at a time, weight/rep steppers, set chips, rest timer (pause/resume/skip), previous performance, suggestions, swap, skip, notes, pain report, autosave + resume after kill (e2e verified), finish early = honest partial. |
| 6 | History, PRs, analytics | Done | Session reports (planned vs completed, volume, PRs with estimate labels), per-exercise e1RM chart, PR list, CSV export. |
| 7 | Indian food nutrition | Done | 145 foods, search with Hindi aliases, servings, custom grams, manual entry, custom foods, source labels (label/database/manual), edit/delete, targets from Mifflin-St Jeor. Saved meals table exists, UI not built (Partial). Photo recognition not done. |
| 8 | Hydration | Done | Target estimate, quick-adds, custom, edit/delete/undo, timestamped log, week/month charts, local-date reset, tz offset stored, reminders. |
| 9 | Body measurements | Done | 7 types + custom, dated entries, edit/delete, deltas, chart, CSV. Progress photos: table only, UI not built (Not done). |
| 10 | Wearables | Done (untested on device) | Health Connect: steps, active kcal, workouts, weight. Fitbit/Garmin/Apple: not implemented, documented in `WEARABLES.md`. Sleep/HR unavailable via plugin. |
| 11 | Notifications | Done (untested on device) | 10 reminder types, per-reminder enable/time/days/interval/window, quiet hours, master off, snooze, dedupe (planner unit-tested), permission gating, status honesty. Delivery on the phone not yet verified. |
| 12 | Sleep / recovery | Done | Manual daily check-in (sleep, quality, energy, soreness, recovery, stress, readiness), 14-day averages, conservative hints. Tracker sleep: not available. |
| 13 | Gemini AI coach | Done (live call untested) | Off/proxy/direct modes, key never in APK, caps, 429/offline fallbacks, output validation, chat, weekly narrative, exercise explain, session summary, request analysis. The actual Gemini endpoint could not be reached from the build environment; the proxy was tested structurally (health endpoint, auth, upstream error path). |
| 14 | Rescheduling and substitution | Done | Forward reschedule without doubling days, skip, defer to end, training-day change, shorten with explanation; substitution by pattern/equipment/restriction with reasons; red-flag triage stops training. |
| 15 | Offline support | Done | Fully offline by design; no sync queue needed (no backend). Backup = JSON export; restore/import not implemented (Partial). |
| 16 | Secure data / export | Done | App-private SQLite, backups disabled, export JSON + CSV, delete all. No auth needed (single user on own phone). |
| 17 | Improve-my-app centre | Done | Save, categorise, AI proposal (conflicts/impact/tests), status tracking. No automatic code change (by design, stated in UI). |
| 18 | Tests and docs | Done / Partial | 35 unit tests + 17-step e2e pass. APK not compiled here (blocked hosts) — see `TEST-REPORT.md`. |
| — | Habit tracking (§18) | Partial | Adherence, hydration day counts and streak-free milestones appear in the weekly review; no dedicated habit calendar screen. |
| — | Weekly AI review (§20) | Done | Deterministic review with evidence, achievements, improvements, recommendations with accept/defer/reject (deload applies to next week), data-gap labelling, optional AI narrative. |
| — | Profile change adaptation (§24) | Done | Detects programme-affecting fields, asks before rebuilding future sessions, keeps history. |

## Known limitations

1. **APK not built in this environment** — `dl.google.com` / `maven.google.com` blocked. Build via Android Studio, the
   one-line script, or the GitHub Actions workflow (`BUILD-AND-INSTALL.md`).
2. Device-only features (notifications delivery, Health Connect, native SQLite path, share sheet) have not run on a phone yet.
3. No exercise videos/images; instructions are text and clearly labelled as such.
4. Imperial units are a display preference only; entry is metric.
5. No saved-meal UI, no progress-photo UI, no photo food recognition, no JSON import/restore.
6. Fitbit/Garmin direct APIs not implemented (see `WEARABLES.md`).
7. Browser preview persists through IndexedDB (preview only). Android uses the native SQLite file.
8. In-app `prompt()`/`confirm()` dialogs are used for a few quick edits (measurement/hydration edit, confirmations); fine in the WebView but not the polished sheet style.

## Next actions for you

1. Get the APK built (Android Studio on your laptop, or push to GitHub and run the workflow). Install, run onboarding.
2. Profile › Reminders › Allow notifications; enable one with a time two minutes ahead to see delivery.
3. Profile › Connected devices › Connect (if your phone has Health Connect) and Sync now.
4. Start the proxy on your computer with your Gemini key, point the app at it, Test connection.
5. Report anything odd through Improve my app, and send me the text (or the exported JSON) for the next iteration.
