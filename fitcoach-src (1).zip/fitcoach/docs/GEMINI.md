# Gemini configuration and key security

## The rule

A secret compiled into a mobile APK is not a secret: anyone can unzip the APK and read it. FitCoach therefore
never embeds `GEMINI_API_KEY`. The key lives in one of two places you control, and the app works fully without it.

| Mode | Where the key is | Phone needs | Risk |
|---|---|---|---|
| **off** (default) | nowhere | nothing | none; deterministic coaching text only |
| **proxy** (recommended) | `gemini-proxy/.env` on your computer | same Wi-Fi as the computer while using AI | key never leaves your computer; anyone on your Wi-Fi could use the proxy unless you set `PROXY_TOKEN` (do) |
| **direct** | typed into the app; saved in app-private storage (Android SharedPreferences via Capacitor Preferences) | internet | not readable by other apps on an unrooted phone and excluded from backups (`allowBackup=false`, extraction rules), but a rooted device, a forensic backup, or someone with your unlocked phone can read it; HTTPS in transit |

Direct mode is a documented trade-off for personal use, not a secure design for distribution. If you use it:
in Google AI Studio restrict the key to the *Generative Language API*, set a low daily quota, and rotate it if the
phone is lost. "Remove saved key" in Settings › AI coach wipes it; "Delete all my data" does too.

## Proxy setup (zero cost, 2 minutes)

```bash
cp gemini-proxy/.env.example gemini-proxy/.env
# edit gemini-proxy/.env: GEMINI_API_KEY=... and PROXY_TOKEN=some-long-random-string
node gemini-proxy/server.mjs
```

It prints `phone address: http://192.168.x.x:8787`. In the app: Profile › AI coach › mode **proxy**, paste that address
and the same token, tap **Test connection**. Keep the computer awake while you use the coach; everything else in the
app works without it.

The proxy: allow-lists models, caps `maxOutputTokens`, rate-limits to `MAX_PER_MINUTE`, rejects bodies over 64 KB,
and never logs prompt text. Node 18+ only, no npm dependencies.

## What is sent to Gemini

Only derived, non-identifying context: goal, experience level, equipment, diet, reported restriction areas, and for the
task at hand the numbers (weekly adherence, estimated-1RM trend per exercise, hydration/sleep/soreness averages, this
session's sets). Never your name, date of birth, exact measurements, or raw logs. See `src/ai/coach.ts`.

## Behaviour when Gemini is unavailable

Offline, mode off, quota exhausted (HTTP 429), monthly in-app cap reached, misconfiguration or any error → every
coaching surface shows deterministic text generated from your data (`deterministicReviewText`, exercise instructions,
etc.) and says why the AI was not used. Core workouts, logs, hydration, measurements and reminders never depend on it.

## Guardrails

The system prompt forbids diagnosis, invented data, and overriding the programme engine; output is validated
(markdown stripped, length-capped, disclaimer appended). All calls are logged in the `ai_log` table with prompt size
and status only.

## Model

Default `gemini-2.5-flash`; change it in Settings › AI coach (the proxy's `ALLOWED_MODELS` must include it).
