// Pure planning of notification occurrences from reminder settings. Tested without the device.
import type { Reminder } from '../db/types';

export interface QuietHours { enabled: boolean; start: string; end: string } // HH:MM, may wrap midnight

export interface Occurrence {
  id: number; // deterministic numeric id (duplicate-safe)
  reminderId: string;
  weekday: number; // ISO 1..7
  hour: number;
  minute: number;
  title: string;
  body: string;
}

export function hm(s: string): [number, number] {
  const [h, m] = s.split(':').map(Number);
  return [h || 0, m || 0];
}

export function inQuietHours(hour: number, minute: number, q: QuietHours): boolean {
  if (!q.enabled) return false;
  const t = hour * 60 + minute;
  const [sh, sm] = hm(q.start);
  const [eh, em] = hm(q.end);
  const s = sh * 60 + sm, e = eh * 60 + em;
  return s <= e ? t >= s && t < e : t >= s || t < e; // wraps midnight
}

/** Stable 31-bit id from a string so re-scheduling replaces rather than duplicates. */
export function stableId(key: string): number {
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) { h ^= key.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 1) || 1;
}

export const REMINDER_TEXT: Record<Reminder['type'], { title: string; body: string }> = {
  workout: { title: 'Workout today', body: 'Your planned session is ready. Open FitCoach to preview and start.' },
  'missed-workout': { title: 'Missed a session?', body: 'No pressure. Reschedule, skip or move it to later in the block.' },
  water: { title: 'Water', body: 'A quick drink keeps you on track. Log it in one tap.' },
  meal: { title: 'Log your meal', body: 'Add what you ate while it is fresh in mind.' },
  movement: { title: 'Movement break', body: 'A few minutes of walking or stretching.' },
  cardio: { title: 'Cardio or a walk', body: 'Time for your planned conditioning.' },
  bedtime: { title: 'Wind down', body: 'Sleep is part of training. Time to start winding down.' },
  measurement: { title: 'Body measurements', body: 'Same time, same conditions: log weight and waist.' },
  'weekly-review': { title: 'Weekly review', body: 'Your week is summarised and ready to review.' },
  'block-review': { title: 'Programme block review', body: 'Check progress and decide on the next block.' },
};

/** Expand enabled reminders into weekly recurring occurrences, respecting quiet hours and removing duplicates. */
export function planOccurrences(reminders: Reminder[], quiet: QuietHours, allOff: boolean): Occurrence[] {
  if (allOff) return [];
  const out: Occurrence[] = [];
  const seen = new Set<string>();
  for (const r of reminders) {
    if (!r.enabled) continue;
    const text = REMINDER_TEXT[r.type];
    const times: [number, number][] = [];
    if (r.intervalMinutes && r.windowStart && r.windowEnd) {
      const [sh, sm] = hm(r.windowStart);
      const [eh, em] = hm(r.windowEnd);
      for (let t = sh * 60 + sm; t <= eh * 60 + em; t += r.intervalMinutes) times.push([Math.floor(t / 60), t % 60]);
    } else if (r.time) {
      times.push(hm(r.time));
    }
    for (const weekday of r.days) {
      for (const [hour, minute] of times) {
        if (inQuietHours(hour, minute, quiet)) continue;
        const key = `${r.type}|${weekday}|${hour}:${minute}`;
        if (seen.has(key)) continue; // no duplicate notification for the same type and slot
        seen.add(key);
        out.push({ id: stableId(`${r.id}|${key}`), reminderId: r.id, weekday, hour, minute, title: text.title, body: text.body });
      }
    }
  }
  return out;
}

/** ISO weekday (1 Mon..7 Sun) to Capacitor Weekday (1 Sun..7 Sat). */
export function toCapWeekday(iso: number): number {
  return iso === 7 ? 1 : iso + 1;
}
