import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export function toCsv(rows: Record<string, string | number | null>[]): string {
  if (rows.length === 0) return '';
  const cols = Object.keys(rows[0]);
  const esc = (v: string | number | null) => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return [cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\n');
}

/** Save a text file: on Android into the app's Documents folder and open the share sheet; in the browser, download. */
export async function saveTextFile(name: string, content: string, mime: string): Promise<string> {
  if (Capacitor.isNativePlatform()) {
    const r = await Filesystem.writeFile({ path: name, data: content, directory: Directory.Documents, encoding: Encoding.UTF8, recursive: true });
    try { await Share.share({ title: name, url: r.uri, dialogTitle: 'Save or send ' + name }); } catch { /* user cancelled */ }
    return r.uri;
  }
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return name;
}

export async function exportCsv(name: string, rows: Record<string, string | number | null>[]): Promise<string> {
  return saveTextFile(name, toCsv(rows), 'text/csv');
}
