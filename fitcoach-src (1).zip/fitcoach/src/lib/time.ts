// Time helpers. All timestamps stored as ISO-8601 UTC strings; "local_date" columns
// store the calendar day (YYYY-MM-DD) in the user's time zone at the moment of logging,
// so daily totals (hydration, nutrition) follow the local calendar even across time-zone changes.

export function nowIso(d: Date = new Date()): string {
  return d.toISOString();
}

export function localDate(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function tzOffsetMinutes(d: Date = new Date()): number {
  return -d.getTimezoneOffset();
}

export function addDays(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d + days);
  return localDate(dt);
}

export function diffDays(a: string, b: string): number {
  const [ay, am, ad] = a.split('-').map(Number);
  const [by, bm, bd] = b.split('-').map(Number);
  const da = Date.UTC(ay, am - 1, ad);
  const db = Date.UTC(by, bm - 1, bd);
  return Math.round((db - da) / 86400000);
}

/** ISO weekday 1 (Mon) .. 7 (Sun) for a YYYY-MM-DD string. */
export function isoWeekday(dateStr: string): number {
  const [y, m, d] = dateStr.split('-').map(Number);
  const js = new Date(y, m - 1, d).getDay(); // 0 Sun .. 6 Sat
  return js === 0 ? 7 : js;
}

export function formatHm(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}
