// Progression and personal-record logic. Deterministic; the AI never bypasses it.
import type { Exercise, PersonalRecord, SetLog } from '../db/types';
import { uid } from '../lib/time';

export interface LoadSuggestion {
  kg: number | null;
  reason: string;
  change: 'increase' | 'hold' | 'decrease' | 'none';
}

/** Smallest sensible plate jump for an exercise. */
export function incrementFor(ex: Exercise): number {
  const lower = ['squat', 'hinge', 'lunge'].includes(ex.movementPattern);
  if (ex.equipment.includes('barbell')) return lower ? 5 : 2.5;
  if (ex.equipment.includes('machine')) return 5;
  if (ex.equipment.includes('dumbbell') || ex.equipment.includes('kettlebell')) return 2.5;
  if (ex.equipment.includes('cable')) return 2.5;
  return 0;
}

export function isBodyweightLoad(ex: Exercise): boolean {
  return ex.equipment.every((e) => e === 'bodyweight' || e === 'bench' || e === 'pull-up-bar' || e === 'band');
}

/**
 * Double progression: hold the load until every working set reaches the top of the rep range
 * with acceptable effort, then add the smallest increment. Reduce after two consecutive sessions
 * where most sets fall below the bottom of the range. Never progresses after a single session
 * just because it was completed.
 */
export function suggestLoad(
  ex: Exercise,
  repMin: number,
  repMax: number,
  last: SetLog[],
  previous: SetLog[],
  lastSessionRpe: number | null,
  lastSessionSoreness: number | null,
): LoadSuggestion {
  if (repMax === 0) return { kg: null, reason: 'Timed exercise', change: 'none' };
  if (isBodyweightLoad(ex)) {
    if (last.length === 0) return { kg: null, reason: 'Bodyweight: work within the rep range', change: 'none' };
    const allTop = last.every((s) => s.reps >= repMax);
    return allTop
      ? { kg: null, reason: 'All sets hit the top of the range last time: try the harder variation or add a set', change: 'increase' }
      : { kg: null, reason: 'Keep building reps toward the top of the range', change: 'hold' };
  }
  if (last.length === 0) return { kg: null, reason: 'No history yet: pick a load you can lift for the rep range with 2 reps in reserve', change: 'none' };
  const lastKg = Math.max(...last.map((s) => s.weightKg));
  const working = last.filter((s) => s.weightKg === lastKg);
  const allTop = working.length >= 2 && working.every((s) => s.reps >= repMax);
  const highEffort = (lastSessionRpe ?? 0) >= 9 || (lastSessionSoreness ?? 0) >= 4;
  if (allTop && !highEffort) {
    return { kg: lastKg + incrementFor(ex), reason: `Every set reached ${repMax} reps at ${lastKg} kg last time`, change: 'increase' };
  }
  if (allTop && highEffort) {
    return { kg: lastKg, reason: `Reps were there, but effort or soreness was high: repeat ${lastKg} kg once more`, change: 'hold' };
  }
  const belowMin = (sets: SetLog[]) => sets.length > 0 && sets.filter((s) => s.reps < repMin).length >= Math.ceil(sets.length / 2);
  if (belowMin(working) && belowMin(previous.filter((s) => s.weightKg >= lastKg))) {
    const dec = Math.max(incrementFor(ex), Math.round((lastKg * 0.1) / 2.5) * 2.5);
    return { kg: Math.max(0, lastKg - dec), reason: `Most sets fell below ${repMin} reps in two sessions: reduce and rebuild`, change: 'decrease' };
  }
  return { kg: lastKg, reason: `Stay at ${lastKg} kg and work toward ${repMax} reps on every set`, change: 'hold' };
}

/** Epley estimate, only meaningful for 1–12 reps. Always labelled as an estimate in the UI. */
export function estimateOneRm(weightKg: number, reps: number): number | null {
  if (reps < 1 || reps > 12 || weightKg <= 0) return null;
  return Math.round(weightKg * (1 + reps / 30) * 10) / 10;
}

/** Determine which completed sets set a new personal record against existing records. */
export function detectPersonalRecords(exerciseId: string, completedSets: SetLog[], existing: PersonalRecord[]): PersonalRecord[] {
  const out: PersonalRecord[] = [];
  const valid = completedSets.filter((s) => s.completed && s.reps > 0 && s.weightKg > 0);
  if (valid.length === 0) return out;
  const prevHeaviest = Math.max(0, ...existing.filter((p) => p.type === 'heaviest').map((p) => p.value));
  const heaviest = valid.reduce((a, s) => (s.weightKg > a.weightKg ? s : a));
  if (heaviest.weightKg > prevHeaviest) {
    out.push({ id: uid(), exerciseId, type: 'heaviest', weightKg: heaviest.weightKg, reps: heaviest.reps, value: heaviest.weightKg, setLogId: heaviest.id, achievedAt: heaviest.loggedAt });
  }
  const prevE1 = Math.max(0, ...existing.filter((p) => p.type === 'best-e1rm').map((p) => p.value));
  let bestE1: { v: number; s: SetLog } | null = null;
  for (const s of valid) {
    const v = estimateOneRm(s.weightKg, s.reps);
    if (v != null && (!bestE1 || v > bestE1.v)) bestE1 = { v, s };
  }
  if (bestE1 && bestE1.v > prevE1) {
    out.push({ id: uid(), exerciseId, type: 'best-e1rm', weightKg: bestE1.s.weightKg, reps: bestE1.s.reps, value: bestE1.v, setLogId: bestE1.s.id, achievedAt: bestE1.s.loggedAt });
  }
  // most reps at a given weight: compare per weight
  const byWeight = new Map<number, SetLog>();
  for (const s of valid) {
    const cur = byWeight.get(s.weightKg);
    if (!cur || s.reps > cur.reps) byWeight.set(s.weightKg, s);
  }
  for (const [w, s] of byWeight) {
    const prev = Math.max(0, ...existing.filter((p) => p.type === 'most-reps-at-weight' && p.weightKg === w).map((p) => p.reps));
    if (s.reps > prev && prev > 0) {
      out.push({ id: uid(), exerciseId, type: 'most-reps-at-weight', weightKg: w, reps: s.reps, value: s.reps, setLogId: s.id, achievedAt: s.loggedAt });
    }
  }
  return out;
}

export function volumeKg(sets: SetLog[]): number {
  return sets.filter((s) => s.completed).reduce((a, s) => a + s.weightKg * s.reps, 0);
}
