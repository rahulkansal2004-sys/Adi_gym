// Gemini coaching client.
//
// Three modes, chosen by the user in Settings > AI coach:
//   off    : no network calls; deterministic coaching text only.
//   proxy  : the app calls a small server on YOUR computer (gemini-proxy/), which holds the key.
//            The key never leaves your computer. Recommended for testing at home.
//   direct : the app calls Gemini itself with a key you type into the app. The key is stored in
//            app-private storage on the phone; it is NOT compiled into the APK. See docs/GEMINI.md
//            for the trade-off: anyone with full access to the phone (root, backup extraction) could
//            read it, so restrict the key in Google AI Studio and keep a quota cap on it.
//
// The deterministic engines own every number the app records; the AI only explains and suggests.
import { Preferences } from '@capacitor/preferences';
import { logAi } from '../db/repos';

export type AiMode = 'off' | 'proxy' | 'direct';

export interface AiConfig {
  mode: AiMode;
  proxyUrl: string; // e.g. http://192.168.1.10:8787
  proxyToken: string; // shared secret configured on the proxy (optional)
  model: string; // e.g. gemini-2.5-flash
  monthlyCallCap: number; // app-side usage limit
}

export const DEFAULT_AI_CONFIG: AiConfig = { mode: 'off', proxyUrl: '', proxyToken: '', model: 'gemini-2.5-flash', monthlyCallCap: 300 };

const CONFIG_KEY = 'ai_config';
const DIRECT_KEY = 'ai_direct_api_key';
const USAGE_KEY = 'ai_usage';

export async function loadAiConfig(): Promise<AiConfig> {
  const r = await Preferences.get({ key: CONFIG_KEY });
  return r.value ? { ...DEFAULT_AI_CONFIG, ...(JSON.parse(r.value) as Partial<AiConfig>) } : { ...DEFAULT_AI_CONFIG };
}

export async function saveAiConfig(c: AiConfig): Promise<void> {
  await Preferences.set({ key: CONFIG_KEY, value: JSON.stringify(c) });
}

export async function setDirectApiKey(key: string | null): Promise<void> {
  if (key) await Preferences.set({ key: DIRECT_KEY, value: key });
  else await Preferences.remove({ key: DIRECT_KEY });
}

export async function hasDirectApiKey(): Promise<boolean> {
  return !!(await Preferences.get({ key: DIRECT_KEY })).value;
}

async function usageThisMonth(): Promise<{ month: string; calls: number }> {
  const month = new Date().toISOString().slice(0, 7);
  const r = await Preferences.get({ key: USAGE_KEY });
  const u = r.value ? (JSON.parse(r.value) as { month: string; calls: number }) : { month, calls: 0 };
  return u.month === month ? u : { month, calls: 0 };
}

async function bumpUsage(): Promise<void> {
  const u = await usageThisMonth();
  await Preferences.set({ key: USAGE_KEY, value: JSON.stringify({ month: u.month, calls: u.calls + 1 }) });
}

export type AiResult =
  | { ok: true; text: string; mode: AiMode }
  | { ok: false; reason: 'disabled' | 'offline' | 'quota' | 'cap' | 'config' | 'error'; message: string };

export interface AiRequest {
  kind: string; // for the log: 'weekly-review' | 'chat' | 'explain' | 'summary' | 'improve-request'
  system: string;
  user: string;
  maxOutputTokens?: number;
  temperature?: number;
}

const SAFETY_SYSTEM = `You are a cautious fitness coach inside a personal training app. Rules:
- Give general fitness guidance only; never diagnose, prescribe medication or tell the user to stop prescribed treatment.
- If the user mentions chest pain, fainting, severe breathlessness, sudden swelling or persistent/sharp pain, tell them to stop training and seek medical assessment (urgent care for emergency signs) before anything else.
- Use ONLY the numbers given in the context. Never invent workouts, weights, steps or sleep data. If data is missing, say so.
- Do not promise fat loss, muscle gain or a specific appearance. No extreme diets or supplement claims.
- The app's programme engine decides load changes; you may explain or suggest, never override.
- Be concise, warm and non-judgmental. Plain text, short paragraphs, no markdown headings.`;

function isOnline(): boolean {
  return typeof navigator === 'undefined' ? true : navigator.onLine !== false;
}

export async function askGemini(req: AiRequest): Promise<AiResult> {
  const cfg = await loadAiConfig();
  if (cfg.mode === 'off') return { ok: false, reason: 'disabled', message: 'AI coaching is off. Turn it on in Settings > AI coach.' };
  if (!isOnline()) return { ok: false, reason: 'offline', message: 'You are offline. The AI coach needs an internet connection; everything else keeps working.' };
  const usage = await usageThisMonth();
  if (usage.calls >= cfg.monthlyCallCap) return { ok: false, reason: 'cap', message: `Monthly AI call cap (${cfg.monthlyCallCap}) reached. Raise it in Settings if you want more.` };

  const body = {
    systemInstruction: { parts: [{ text: SAFETY_SYSTEM + '\n\n' + req.system }] },
    contents: [{ role: 'user', parts: [{ text: req.user }] }],
    generationConfig: { temperature: req.temperature ?? 0.4, maxOutputTokens: req.maxOutputTokens ?? 700 },
  };
  const promptChars = req.system.length + req.user.length;

  try {
    let res: Response;
    if (cfg.mode === 'proxy') {
      if (!cfg.proxyUrl) return { ok: false, reason: 'config', message: 'Set the proxy address in Settings > AI coach (for example http://192.168.1.10:8787).' };
      res = await fetchWithTimeout(`${cfg.proxyUrl.replace(/\/$/, '')}/v1/generate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(cfg.proxyToken ? { 'x-proxy-token': cfg.proxyToken } : {}) },
        body: JSON.stringify({ model: cfg.model, body }),
      });
    } else {
      const key = (await Preferences.get({ key: DIRECT_KEY })).value;
      if (!key) return { ok: false, reason: 'config', message: 'Enter your Gemini API key in Settings > AI coach, or switch to proxy mode.' };
      res = await fetchWithTimeout(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.model)}:generateContent`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify(body),
      });
    }
    await bumpUsage();
    if (res.status === 429) {
      await logAi(req.kind, cfg.mode, promptChars, null, 'quota');
      return { ok: false, reason: 'quota', message: 'Gemini quota exhausted for now (HTTP 429). Try again later; the deterministic coach is shown instead.' };
    }
    if (!res.ok) {
      const t = await safeText(res);
      await logAi(req.kind, cfg.mode, promptChars, null, `http-${res.status}`);
      return { ok: false, reason: 'error', message: `AI request failed (HTTP ${res.status}). ${t.slice(0, 160)}` };
    }
    const json = (await res.json()) as GeminiResponse;
    const text = extractText(json);
    if (!text) {
      await logAi(req.kind, cfg.mode, promptChars, null, 'empty');
      return { ok: false, reason: 'error', message: 'The AI returned no usable text (possibly blocked by safety filters).' };
    }
    const validated = validateOutput(text);
    await logAi(req.kind, cfg.mode, promptChars, validated, 'ok');
    return { ok: true, text: validated, mode: cfg.mode };
  } catch (e) {
    await logAi(req.kind, cfg.mode, promptChars, null, 'network');
    return { ok: false, reason: 'error', message: `Could not reach the AI service: ${(e as Error).message}` };
  }
}

interface GeminiResponse {
  candidates?: { content?: { parts?: { text?: string }[] }; finishReason?: string }[];
  promptFeedback?: { blockReason?: string };
}

function extractText(r: GeminiResponse): string {
  return (r.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? '').join('').trim();
}

/** Output validation: strip markdown noise, cap length, and append the standing disclaimer. */
export function validateOutput(text: string): string {
  let t = text.replace(/^#+\s*/gm, '').replace(/\*\*/g, '').trim();
  if (t.length > 4000) t = t.slice(0, 4000) + '…';
  if (!/not medical advice|general fitness guidance/i.test(t)) t += '\n\nGeneral fitness guidance, not medical advice.';
  return t;
}

async function safeText(res: Response): Promise<string> {
  try { return await res.text(); } catch { return ''; }
}

async function fetchWithTimeout(url: string, init: RequestInit, ms = 30000): Promise<Response> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try { return await fetch(url, { ...init, signal: ctl.signal }); } finally { clearTimeout(t); }
}

/** Test the current configuration with a tiny request. */
export async function testAiConnection(): Promise<AiResult> {
  return askGemini({ kind: 'test', system: 'Reply with the single word OK.', user: 'Connection test.', maxOutputTokens: 5, temperature: 0 });
}
