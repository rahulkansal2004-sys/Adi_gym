import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Capacitor } from '@capacitor/core';
import './styles.css';
import { App } from './app/App';
import { AppProvider } from './app/store';
import { migrateAndSeed } from './db';
import type { SqlDriver } from './db/driver';

async function openDatabase(): Promise<SqlDriver> {
  if (Capacitor.isNativePlatform()) {
    const { NativeSqliteDriver } = await import('./db/native');
    return NativeSqliteDriver.open();
  }
  // Browser preview only: sql.js in memory, persisted to IndexedDB. The Android app uses native SQLite.
  const [{ default: initSqlJs }, { SqlJsDriver }] = await Promise.all([import('sql.js'), import('./db/sqljs')]);
  const SQL = await initSqlJs({ locateFile: (f: string) => `./${f}` });
  const driver = await SqlJsDriver.open(SQL, idbPersistence());
  window.addEventListener('pagehide', () => { void driver.flush(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void driver.flush(); });
  return driver;
}

function idbPersistence() {
  const open = () => new Promise<IDBDatabase>((res, rej) => {
    const r = indexedDB.open('fitcoach-preview', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('db');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  return {
    async load() {
      try {
        const d = await open();
        return await new Promise<Uint8Array | null>((res) => {
          const req = d.transaction('db').objectStore('db').get('main');
          req.onsuccess = () => res((req.result as Uint8Array) ?? null);
          req.onerror = () => res(null);
        });
      } catch { return null; }
    },
    async save(bytes: Uint8Array) {
      try { const d = await open(); d.transaction('db', 'readwrite').objectStore('db').put(bytes, 'main'); } catch { /* preview only */ }
    },
  };
}

async function boot() {
  const root = createRoot(document.getElementById('root')!);
  try {
    const driver = await openDatabase();
    await migrateAndSeed(driver);
    root.render(<StrictMode><AppProvider><App /></AppProvider></StrictMode>);
  } catch (e) {
    root.render(<div style={{ padding: 24 }}><h1>FitCoach could not open its database</h1><p>{String((e as Error).message)}</p></div>);
  }
}

void boot();
