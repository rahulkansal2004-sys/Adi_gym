import { db, getSetting, setSetting } from './index';
import type { SqlValue } from './driver';
import type {
  Profile, Goal, GoalId, Exercise, Food, Programme, PlannedWorkout, PlannedExercise,
  Session, ExerciseLog, SetLog, PersonalRecord, NutritionEntry, HydrationEntry,
  Measurement, RecoveryEntry, Reminder,
} from './types';
import { nowIso, localDate, tzOffsetMinutes, uid } from '../lib/time';

const b = (v: SqlValue) => v === 1 || v === '1';

export async function audit(entity: string, entityId: string | null, action: string, detail?: string) {
  await db().run('INSERT INTO audit(id, entity, entity_id, action, detail, at) VALUES(?,?,?,?,?,?)', [
    uid(), entity, entityId, action, detail ?? null, nowIso(),
  ]);
}

export { getSetting, setSetting };

// ---------- Profile ----------
const DEFAULT_PROFILE: Profile = {
  name: null, dob: null, sex: null, heightCm: null, weightKg: null, targetWeightKg: null, waistCm: null,
  experience: 'beginner-some', activityLevel: 'light', daysPerWeek: 3, sessionMinutes: 45,
  equipment: ['bodyweight'], location: 'home', diet: 'vegetarian', restrictions: [], restrictionNotes: null,
  restrictionsConfirmedAt: null, excludeGluteIsolation: false, sleepHours: null,
  unitsWeight: 'kg', unitsLength: 'cm', unitsVolume: 'ml', timezone: null, nutritionEnabled: true,
  onboardingComplete: false,
};

function rowToProfile(r: Record<string, SqlValue>): Profile {
  return {
    name: (r.name as string) ?? null,
    dob: (r.dob as string) ?? null,
    sex: (r.sex as Profile['sex']) ?? null,
    heightCm: (r.height_cm as number) ?? null,
    weightKg: (r.weight_kg as number) ?? null,
    targetWeightKg: (r.target_weight_kg as number) ?? null,
    waistCm: (r.waist_cm as number) ?? null,
    experience: r.experience as Profile['experience'],
    activityLevel: r.activity_level as Profile['activityLevel'],
    daysPerWeek: r.days_per_week as number,
    sessionMinutes: r.session_minutes as number,
    equipment: JSON.parse(r.equipment as string),
    location: r.location as Profile['location'],
    diet: r.diet as Profile['diet'],
    restrictions: JSON.parse(r.restrictions as string),
    restrictionNotes: (r.restriction_notes as string) ?? null,
    restrictionsConfirmedAt: (r.restrictions_confirmed_at as string) ?? null,
    excludeGluteIsolation: b(r.exclude_glute_isolation),
    sleepHours: (r.sleep_hours as number) ?? null,
    unitsWeight: r.units_weight as Profile['unitsWeight'],
    unitsLength: r.units_length as Profile['unitsLength'],
    unitsVolume: r.units_volume as Profile['unitsVolume'],
    timezone: (r.timezone as string) ?? null,
    nutritionEnabled: b(r.nutrition_enabled),
    onboardingComplete: b(r.onboarding_complete),
  };
}

export async function getProfile(): Promise<Profile> {
  const rows = await db().query('SELECT * FROM profile WHERE id = 1');
  return rows[0] ? rowToProfile(rows[0]) : { ...DEFAULT_PROFILE };
}

export async function saveProfile(patch: Partial<Profile>): Promise<Profile> {
  const current = await getProfile();
  const p: Profile = { ...current, ...patch };
  const now = nowIso();
  await db().run(
    `INSERT INTO profile(id, name, dob, sex, height_cm, weight_kg, target_weight_kg, waist_cm, experience, activity_level,
       days_per_week, session_minutes, equipment, location, diet, restrictions, restriction_notes, restrictions_confirmed_at,
       exclude_glute_isolation, sleep_hours, units_weight, units_length, units_volume, timezone, nutrition_enabled,
       onboarding_complete, created_at, updated_at)
     VALUES(1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
     ON CONFLICT(id) DO UPDATE SET name=excluded.name, dob=excluded.dob, sex=excluded.sex, height_cm=excluded.height_cm,
       weight_kg=excluded.weight_kg, target_weight_kg=excluded.target_weight_kg, waist_cm=excluded.waist_cm,
       experience=excluded.experience, activity_level=excluded.activity_level, days_per_week=excluded.days_per_week,
       session_minutes=excluded.session_minutes, equipment=excluded.equipment, location=excluded.location, diet=excluded.diet,
       restrictions=excluded.restrictions, restriction_notes=excluded.restriction_notes,
       restrictions_confirmed_at=excluded.restrictions_confirmed_at, exclude_glute_isolation=excluded.exclude_glute_isolation,
       sleep_hours=excluded.sleep_hours, units_weight=excluded.units_weight, units_length=excluded.units_length,
       units_volume=excluded.units_volume, timezone=excluded.timezone, nutrition_enabled=excluded.nutrition_enabled,
       onboarding_complete=excluded.onboarding_complete, updated_at=excluded.updated_at`,
    [
      p.name, p.dob, p.sex, p.heightCm, p.weightKg, p.targetWeightKg, p.waistCm, p.experience, p.activityLevel,
      p.daysPerWeek, p.sessionMinutes, JSON.stringify(p.equipment), p.location, p.diet, JSON.stringify(p.restrictions),
      p.restrictionNotes, p.restrictionsConfirmedAt, p.excludeGluteIsolation ? 1 : 0, p.sleepHours, p.unitsWeight,
      p.unitsLength, p.unitsVolume, p.timezone, p.nutritionEnabled ? 1 : 0, p.onboardingComplete ? 1 : 0, now, now,
    ],
  );
  if (patch.weightKg != null && patch.weightKg !== current.weightKg) {
    await addMeasurement({ type: 'weight', value: patch.weightKg, unit: 'kg', note: 'From profile' });
  }
  await audit('profile', '1', 'update', JSON.stringify(Object.keys(patch)));
  return p;
}

// ---------- Goals ----------
export async function getActiveGoal(): Promise<Goal | null> {
  const r = (await db().query('SELECT * FROM goals WHERE active = 1 ORDER BY set_at DESC LIMIT 1'))[0];
  if (!r) return null;
  return {
    id: r.id as string, primaryGoal: r.primary_goal as GoalId, secondaryGoal: (r.secondary_goal as GoalId) ?? null,
    customText: (r.custom_text as string) ?? null, active: true, setAt: r.set_at as string,
  };
}

export async function setGoal(primary: GoalId, secondary: GoalId | null, customText: string | null): Promise<Goal> {
  await db().run('UPDATE goals SET active = 0 WHERE active = 1');
  const g: Goal = { id: uid(), primaryGoal: primary, secondaryGoal: secondary, customText, active: true, setAt: nowIso() };
  await db().run('INSERT INTO goals(id, primary_goal, secondary_goal, custom_text, active, set_at) VALUES(?,?,?,?,1,?)', [
    g.id, g.primaryGoal, g.secondaryGoal, g.customText, g.setAt,
  ]);
  await audit('goal', g.id, 'set', `${primary}${secondary ? '+' + secondary : ''}`);
  return g;
}

// ---------- Exercises ----------
export async function listExercises(): Promise<Exercise[]> {
  const rows = await db().query<{ json: string; is_custom: number }>('SELECT json, is_custom FROM exercises ORDER BY name');
  return rows.map((r) => ({ ...(JSON.parse(r.json) as Exercise), isCustom: b(r.is_custom) }));
}

export async function getExercise(id: string): Promise<Exercise | null> {
  const r = (await db().query<{ json: string }>('SELECT json FROM exercises WHERE id = ?', [id]))[0];
  return r ? (JSON.parse(r.json) as Exercise) : null;
}

export async function getExercisesByIds(ids: string[]): Promise<Map<string, Exercise>> {
  const map = new Map<string, Exercise>();
  if (ids.length === 0) return map;
  const unique = [...new Set(ids)];
  const rows = await db().query<{ id: string; json: string }>(
    `SELECT id, json FROM exercises WHERE id IN (${unique.map(() => '?').join(',')})`, unique,
  );
  for (const r of rows) map.set(r.id, JSON.parse(r.json));
  return map;
}

// ---------- Programmes and planned workouts ----------
function rowToProgramme(r: Record<string, SqlValue>): Programme {
  return {
    id: r.id as string, name: r.name as string, template: r.template as string, goal: r.goal as GoalId,
    daysPerWeek: r.days_per_week as number, weeks: r.weeks as number, startDate: r.start_date as string,
    status: r.status as Programme['status'], config: JSON.parse(r.config_json as string), createdAt: r.created_at as string,
  };
}

function rowToPlanned(r: Record<string, SqlValue>): PlannedWorkout {
  return {
    id: r.id as string, programmeId: r.programme_id as string, week: r.week as number, dayIndex: r.day_index as number,
    scheduledDate: r.scheduled_date as string, name: r.name as string, focus: r.focus as string,
    exercises: JSON.parse(r.exercises_json as string) as PlannedExercise[], status: r.status as PlannedWorkout['status'],
    estimatedMinutes: r.estimated_minutes as number,
  };
}

export async function getActiveProgramme(): Promise<Programme | null> {
  const r = (await db().query(`SELECT * FROM programmes WHERE status = 'active' ORDER BY created_at DESC LIMIT 1`))[0];
  return r ? rowToProgramme(r) : null;
}

export async function saveProgramme(p: Programme, workouts: PlannedWorkout[]): Promise<void> {
  const stmts: { sql: string; params: SqlValue[] }[] = [
    { sql: `UPDATE programmes SET status = 'archived' WHERE status = 'active'`, params: [] },
    {
      sql: `INSERT INTO programmes(id, name, template, goal, days_per_week, weeks, start_date, status, config_json, created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)`,
      params: [p.id, p.name, p.template, p.goal, p.daysPerWeek, p.weeks, p.startDate, p.status, JSON.stringify(p.config), p.createdAt],
    },
  ];
  for (const w of workouts) {
    stmts.push({
      sql: `INSERT INTO planned_workouts(id, programme_id, week, day_index, scheduled_date, name, focus, exercises_json, status, estimated_minutes)
            VALUES(?,?,?,?,?,?,?,?,?,?)`,
      params: [w.id, w.programmeId, w.week, w.dayIndex, w.scheduledDate, w.name, w.focus, JSON.stringify(w.exercises), w.status, w.estimatedMinutes],
    });
  }
  await db().batch(stmts);
  await audit('programme', p.id, 'create', `${p.template} ${p.daysPerWeek}d x ${p.weeks}w`);
}

export async function listPlannedWorkouts(programmeId: string): Promise<PlannedWorkout[]> {
  const rows = await db().query('SELECT * FROM planned_workouts WHERE programme_id = ? ORDER BY scheduled_date, day_index', [programmeId]);
  return rows.map(rowToPlanned);
}

export async function getPlannedWorkout(id: string): Promise<PlannedWorkout | null> {
  const r = (await db().query('SELECT * FROM planned_workouts WHERE id = ?', [id]))[0];
  return r ? rowToPlanned(r) : null;
}

export async function updatePlannedWorkout(w: PlannedWorkout): Promise<void> {
  await db().run(
    `UPDATE planned_workouts SET scheduled_date=?, name=?, focus=?, exercises_json=?, status=?, estimated_minutes=? WHERE id=?`,
    [w.scheduledDate, w.name, w.focus, JSON.stringify(w.exercises), w.status, w.estimatedMinutes, w.id],
  );
}

/** Next not-yet-done planned workout on or after today (or the most recent overdue one). */
export async function getNextPlannedWorkout(programmeId: string, today = localDate()): Promise<PlannedWorkout | null> {
  const r = (await db().query(
    `SELECT * FROM planned_workouts WHERE programme_id = ? AND status IN ('planned','rescheduled','partial')
     ORDER BY scheduled_date, day_index LIMIT 1`, [programmeId],
  ))[0];
  if (!r) return null;
  const w = rowToPlanned(r);
  return w.scheduledDate <= today ? w : w; // overdue first, else the next upcoming
}

// ---------- Sessions ----------
function rowToSession(r: Record<string, SqlValue>): Session {
  return {
    id: r.id as string, plannedWorkoutId: (r.planned_workout_id as string) ?? null, programmeId: (r.programme_id as string) ?? null,
    name: r.name as string, startedAt: r.started_at as string, endedAt: (r.ended_at as string) ?? null,
    status: r.status as Session['status'], durationS: (r.duration_s as number) ?? null, rpe: (r.rpe as number) ?? null,
    notes: (r.notes as string) ?? null,
  };
}

export async function createSession(planned: PlannedWorkout | null, name: string): Promise<{ session: Session; logs: ExerciseLog[] }> {
  const s: Session = {
    id: uid(), plannedWorkoutId: planned?.id ?? null, programmeId: planned?.programmeId ?? null, name,
    startedAt: nowIso(), endedAt: null, status: 'in_progress', durationS: null, rpe: null, notes: null,
  };
  const logs: ExerciseLog[] = (planned?.exercises ?? []).map((e, i) => ({
    id: uid(), sessionId: s.id, exerciseId: e.exerciseId, orderIndex: i, plannedSets: e.sets, repMin: e.repMin,
    repMax: e.repMax, restSeconds: e.restSeconds, substitutedFrom: null, substitutionReason: null, skipped: false,
    painReported: false, notes: null,
  }));
  const stmts: { sql: string; params: SqlValue[] }[] = [{
    sql: `INSERT INTO sessions(id, planned_workout_id, programme_id, name, started_at, status) VALUES(?,?,?,?,?,'in_progress')`,
    params: [s.id, s.plannedWorkoutId, s.programmeId, s.name, s.startedAt],
  }];
  for (const l of logs) {
    stmts.push({
      sql: `INSERT INTO exercise_logs(id, session_id, exercise_id, order_index, planned_sets, rep_min, rep_max, rest_seconds)
            VALUES(?,?,?,?,?,?,?,?)`,
      params: [l.id, l.sessionId, l.exerciseId, l.orderIndex, l.plannedSets, l.repMin, l.repMax, l.restSeconds],
    });
  }
  await db().batch(stmts);
  await audit('session', s.id, 'start', name);
  return { session: s, logs };
}

export async function getInProgressSession(): Promise<Session | null> {
  const r = (await db().query(`SELECT * FROM sessions WHERE status = 'in_progress' ORDER BY started_at DESC LIMIT 1`))[0];
  return r ? rowToSession(r) : null;
}

export async function getSession(id: string): Promise<Session | null> {
  const r = (await db().query('SELECT * FROM sessions WHERE id = ?', [id]))[0];
  return r ? rowToSession(r) : null;
}

export async function listSessions(limit = 50): Promise<Session[]> {
  const rows = await db().query(`SELECT * FROM sessions WHERE status != 'in_progress' ORDER BY started_at DESC LIMIT ?`, [limit]);
  return rows.map(rowToSession);
}

export async function listExerciseLogs(sessionId: string): Promise<ExerciseLog[]> {
  const rows = await db().query('SELECT * FROM exercise_logs WHERE session_id = ? ORDER BY order_index', [sessionId]);
  return rows.map((r) => ({
    id: r.id as string, sessionId: r.session_id as string, exerciseId: r.exercise_id as string, orderIndex: r.order_index as number,
    plannedSets: r.planned_sets as number, repMin: r.rep_min as number, repMax: r.rep_max as number, restSeconds: r.rest_seconds as number,
    substitutedFrom: (r.substituted_from as string) ?? null, substitutionReason: (r.substitution_reason as string) ?? null,
    skipped: b(r.skipped), painReported: b(r.pain_reported), notes: (r.notes as string) ?? null,
  }));
}

export async function updateExerciseLog(l: ExerciseLog): Promise<void> {
  await db().run(
    `UPDATE exercise_logs SET exercise_id=?, substituted_from=?, substitution_reason=?, skipped=?, pain_reported=?, notes=? WHERE id=?`,
    [l.exerciseId, l.substitutedFrom, l.substitutionReason, l.skipped ? 1 : 0, l.painReported ? 1 : 0, l.notes, l.id],
  );
}

export async function addExerciseLog(sessionId: string, exerciseId: string, orderIndex: number, sets: number, repMin: number, repMax: number, rest: number): Promise<ExerciseLog> {
  await db().run('UPDATE exercise_logs SET order_index = order_index + 1 WHERE session_id = ? AND order_index >= ?', [sessionId, orderIndex]);
  const l: ExerciseLog = {
    id: uid(), sessionId, exerciseId, orderIndex, plannedSets: sets, repMin, repMax, restSeconds: rest,
    substitutedFrom: null, substitutionReason: null, skipped: false, painReported: false, notes: null,
  };
  await db().run(
    `INSERT INTO exercise_logs(id, session_id, exercise_id, order_index, planned_sets, rep_min, rep_max, rest_seconds) VALUES(?,?,?,?,?,?,?,?)`,
    [l.id, l.sessionId, l.exerciseId, l.orderIndex, l.plannedSets, l.repMin, l.repMax, l.restSeconds],
  );
  return l;
}

function rowToSet(r: Record<string, SqlValue>): SetLog {
  return {
    id: r.id as string, exerciseLogId: r.exercise_log_id as string, sessionId: r.session_id as string, exerciseId: r.exercise_id as string,
    setIndex: r.set_index as number, weightKg: r.weight_kg as number, reps: r.reps as number, completed: b(r.completed),
    rpe: (r.rpe as number) ?? null, loggedAt: r.logged_at as string,
  };
}

export async function listSetLogs(sessionId: string): Promise<SetLog[]> {
  const rows = await db().query('SELECT * FROM set_logs WHERE session_id = ? ORDER BY exercise_log_id, set_index', [sessionId]);
  return rows.map(rowToSet);
}

/** Insert or update one set. A set only counts when `completed` is true. */
export async function upsertSetLog(s: Omit<SetLog, 'id' | 'loggedAt'> & { id?: string }): Promise<SetLog> {
  const existing = (await db().query('SELECT * FROM set_logs WHERE exercise_log_id = ? AND set_index = ?', [s.exerciseLogId, s.setIndex]))[0];
  const row: SetLog = {
    id: existing ? (existing.id as string) : s.id ?? uid(), exerciseLogId: s.exerciseLogId, sessionId: s.sessionId,
    exerciseId: s.exerciseId, setIndex: s.setIndex, weightKg: s.weightKg, reps: s.reps, completed: s.completed, rpe: s.rpe,
    loggedAt: nowIso(),
  };
  if (existing) {
    await db().run('UPDATE set_logs SET weight_kg=?, reps=?, completed=?, rpe=?, logged_at=?, exercise_id=? WHERE id=?', [
      row.weightKg, row.reps, row.completed ? 1 : 0, row.rpe, row.loggedAt, row.exerciseId, row.id,
    ]);
  } else {
    await db().run(
      `INSERT INTO set_logs(id, exercise_log_id, session_id, exercise_id, set_index, weight_kg, reps, completed, rpe, logged_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,
      [row.id, row.exerciseLogId, row.sessionId, row.exerciseId, row.setIndex, row.weightKg, row.reps, row.completed ? 1 : 0, row.rpe, row.loggedAt],
    );
  }
  return row;
}

export async function saveSessionState(sessionId: string, state: unknown): Promise<void> {
  await db().run('UPDATE sessions SET state_json = ? WHERE id = ?', [JSON.stringify(state), sessionId]);
}

export async function loadSessionState<T>(sessionId: string): Promise<T | null> {
  const r = (await db().query<{ state_json: string | null }>('SELECT state_json FROM sessions WHERE id = ?', [sessionId]))[0];
  return r?.state_json ? (JSON.parse(r.state_json) as T) : null;
}

export async function finishSession(sessionId: string, status: 'completed' | 'abandoned', rpe: number | null, notes: string | null): Promise<Session> {
  const s = await getSession(sessionId);
  if (!s) throw new Error('session not found');
  const ended = nowIso();
  const durationS = Math.max(0, Math.round((new Date(ended).getTime() - new Date(s.startedAt).getTime()) / 1000));
  await db().run('UPDATE sessions SET status=?, ended_at=?, duration_s=?, rpe=?, notes=? WHERE id=?', [status, ended, durationS, rpe, notes, sessionId]);
  if (s.plannedWorkoutId) {
    const sets = await listSetLogs(sessionId);
    const planned = await getPlannedWorkout(s.plannedWorkoutId);
    if (planned) {
      const plannedSets = planned.exercises.reduce((a, e) => a + e.sets, 0);
      const done = sets.filter((x) => x.completed).length;
      planned.status = status === 'abandoned' && done === 0 ? 'planned' : done >= plannedSets ? 'done' : 'partial';
      await updatePlannedWorkout(planned);
    }
  }
  await audit('session', sessionId, status);
  return { ...s, status, endedAt: ended, durationS, rpe, notes };
}

/** Completed sets for an exercise across history, newest first. */
export async function exerciseHistory(exerciseId: string, limit = 200): Promise<SetLog[]> {
  const rows = await db().query(
    `SELECT s.* FROM set_logs s JOIN sessions se ON se.id = s.session_id
     WHERE s.exercise_id = ? AND s.completed = 1 AND se.status = 'completed' ORDER BY s.logged_at DESC LIMIT ?`,
    [exerciseId, limit],
  );
  return rows.map(rowToSet);
}

/** Completed sets of the most recent completed session that included this exercise. */
export async function lastPerformance(exerciseId: string, beforeSessionId?: string): Promise<SetLog[]> {
  const r = (await db().query<{ session_id: string }>(
    `SELECT s.session_id FROM set_logs s JOIN sessions se ON se.id = s.session_id
     WHERE s.exercise_id = ? AND s.completed = 1 AND se.status = 'completed' ${beforeSessionId ? 'AND s.session_id != ?' : ''}
     ORDER BY s.logged_at DESC LIMIT 1`,
    beforeSessionId ? [exerciseId, beforeSessionId] : [exerciseId],
  ))[0];
  if (!r) return [];
  const rows = await db().query('SELECT * FROM set_logs WHERE session_id = ? AND exercise_id = ? AND completed = 1 ORDER BY set_index', [r.session_id, exerciseId]);
  return rows.map(rowToSet);
}

// ---------- Personal records ----------
export async function listPersonalRecords(exerciseId?: string): Promise<PersonalRecord[]> {
  const rows = exerciseId
    ? await db().query('SELECT * FROM personal_records WHERE exercise_id = ? ORDER BY achieved_at DESC', [exerciseId])
    : await db().query('SELECT * FROM personal_records ORDER BY achieved_at DESC');
  return rows.map((r) => ({
    id: r.id as string, exerciseId: r.exercise_id as string, type: r.type as PersonalRecord['type'], weightKg: r.weight_kg as number,
    reps: r.reps as number, value: r.value as number, setLogId: r.set_log_id as string, achievedAt: r.achieved_at as string,
  }));
}

export async function insertPersonalRecord(pr: PersonalRecord): Promise<void> {
  await db().run('INSERT INTO personal_records(id, exercise_id, type, weight_kg, reps, value, set_log_id, achieved_at) VALUES(?,?,?,?,?,?,?,?)', [
    pr.id, pr.exerciseId, pr.type, pr.weightKg, pr.reps, pr.value, pr.setLogId, pr.achievedAt,
  ]);
}

// ---------- Foods and nutrition ----------
export async function searchFoods(q: string, vegetarianOnly: boolean, limit = 30): Promise<Food[]> {
  const like = `%${q.trim().toLowerCase()}%`;
  const rows = await db().query<{ json: string; is_custom: number }>(
    `SELECT json, is_custom FROM foods WHERE (lower(name) LIKE ? OR lower(json) LIKE ?) ${vegetarianOnly ? 'AND vegetarian = 1' : ''}
     ORDER BY is_custom DESC, name LIMIT ?`,
    [like, like, limit],
  );
  return rows.map((r) => ({ ...(JSON.parse(r.json) as Food), isCustom: b(r.is_custom) }));
}

export async function getFood(id: string): Promise<Food | null> {
  const r = (await db().query<{ json: string }>('SELECT json FROM foods WHERE id = ?', [id]))[0];
  return r ? (JSON.parse(r.json) as Food) : null;
}

export async function addCustomFood(f: Food): Promise<void> {
  await db().run('INSERT INTO foods(id, name, category, vegetarian, is_custom, json) VALUES(?,?,?,?,1,?)', [
    f.id, f.name, f.category, f.vegetarian ? 1 : 0, JSON.stringify(f),
  ]);
}

export async function addNutritionEntry(e: Omit<NutritionEntry, 'id' | 'loggedAt' | 'localDate'> & { localDate?: string }): Promise<NutritionEntry> {
  const row: NutritionEntry = { ...e, id: uid(), loggedAt: nowIso(), localDate: e.localDate ?? localDate() };
  await db().run(
    `INSERT INTO nutrition_entries(id, local_date, meal, food_id, food_name, grams, kcal, protein, carbs, fat, fibre, source, logged_at)
     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [row.id, row.localDate, row.meal, row.foodId, row.foodName, row.grams, row.kcal, row.protein, row.carbs, row.fat, row.fibre, row.source, row.loggedAt],
  );
  return row;
}

export async function updateNutritionEntry(e: NutritionEntry): Promise<void> {
  await db().run('UPDATE nutrition_entries SET meal=?, grams=?, kcal=?, protein=?, carbs=?, fat=?, fibre=?, source=?, food_name=? WHERE id=?', [
    e.meal, e.grams, e.kcal, e.protein, e.carbs, e.fat, e.fibre, e.source, e.foodName, e.id,
  ]);
}

export async function deleteNutritionEntry(id: string): Promise<void> {
  await db().run('UPDATE nutrition_entries SET deleted_at = ? WHERE id = ?', [nowIso(), id]);
}

export async function listNutrition(date: string): Promise<NutritionEntry[]> {
  const rows = await db().query('SELECT * FROM nutrition_entries WHERE local_date = ? AND deleted_at IS NULL ORDER BY logged_at', [date]);
  return rows.map((r) => ({
    id: r.id as string, localDate: r.local_date as string, meal: r.meal as NutritionEntry['meal'], foodId: (r.food_id as string) ?? null,
    foodName: r.food_name as string, grams: r.grams as number, kcal: r.kcal as number, protein: r.protein as number, carbs: r.carbs as number,
    fat: r.fat as number, fibre: r.fibre as number, source: r.source as NutritionEntry['source'], loggedAt: r.logged_at as string,
  }));
}

export async function nutritionDailyTotals(fromDate: string, toDate: string): Promise<{ date: string; kcal: number; protein: number }[]> {
  const rows = await db().query<{ local_date: string; kcal: number; protein: number }>(
    `SELECT local_date, SUM(kcal) kcal, SUM(protein) protein FROM nutrition_entries
     WHERE deleted_at IS NULL AND local_date BETWEEN ? AND ? GROUP BY local_date ORDER BY local_date`, [fromDate, toDate],
  );
  return rows.map((r) => ({ date: r.local_date, kcal: r.kcal, protein: r.protein }));
}

// ---------- Hydration ----------
export async function addHydration(amountMl: number, at: Date = new Date()): Promise<HydrationEntry> {
  const e: HydrationEntry = { id: uid(), localDate: localDate(at), amountMl, loggedAt: nowIso(at) };
  await db().run('INSERT INTO hydration_entries(id, local_date, amount_ml, logged_at, tz_offset_min) VALUES(?,?,?,?,?)', [
    e.id, e.localDate, e.amountMl, e.loggedAt, tzOffsetMinutes(at),
  ]);
  return e;
}

export async function updateHydration(id: string, amountMl: number): Promise<void> {
  await db().run('UPDATE hydration_entries SET amount_ml = ? WHERE id = ?', [amountMl, id]);
}

export async function deleteHydration(id: string): Promise<void> {
  await db().run('UPDATE hydration_entries SET deleted_at = ? WHERE id = ?', [nowIso(), id]);
}

export async function undeleteHydration(id: string): Promise<void> {
  await db().run('UPDATE hydration_entries SET deleted_at = NULL WHERE id = ?', [id]);
}

export async function listHydration(date: string): Promise<HydrationEntry[]> {
  const rows = await db().query('SELECT * FROM hydration_entries WHERE local_date = ? AND deleted_at IS NULL ORDER BY logged_at', [date]);
  return rows.map((r) => ({ id: r.id as string, localDate: r.local_date as string, amountMl: r.amount_ml as number, loggedAt: r.logged_at as string }));
}

export async function hydrationDailyTotals(fromDate: string, toDate: string): Promise<{ date: string; ml: number }[]> {
  const rows = await db().query<{ local_date: string; ml: number }>(
    `SELECT local_date, SUM(amount_ml) ml FROM hydration_entries WHERE deleted_at IS NULL AND local_date BETWEEN ? AND ?
     GROUP BY local_date ORDER BY local_date`, [fromDate, toDate],
  );
  return rows.map((r) => ({ date: r.local_date, ml: r.ml }));
}

// ---------- Measurements ----------
export async function addMeasurement(m: { type: string; value: number; unit: string; note?: string | null; localDate?: string }): Promise<Measurement> {
  const row: Measurement = { id: uid(), localDate: m.localDate ?? localDate(), type: m.type, value: m.value, unit: m.unit, note: m.note ?? null, loggedAt: nowIso() };
  await db().run('INSERT INTO measurements(id, local_date, type, value, unit, note, logged_at) VALUES(?,?,?,?,?,?,?)', [
    row.id, row.localDate, row.type, row.value, row.unit, row.note, row.loggedAt,
  ]);
  return row;
}

export async function updateMeasurement(id: string, value: number, note: string | null): Promise<void> {
  await db().run('UPDATE measurements SET value = ?, note = ? WHERE id = ?', [value, note, id]);
}

export async function deleteMeasurement(id: string): Promise<void> {
  await db().run('UPDATE measurements SET deleted_at = ? WHERE id = ?', [nowIso(), id]);
}

export async function listMeasurements(type?: string, limit = 365): Promise<Measurement[]> {
  const rows = type
    ? await db().query('SELECT * FROM measurements WHERE type = ? AND deleted_at IS NULL ORDER BY local_date DESC, logged_at DESC LIMIT ?', [type, limit])
    : await db().query('SELECT * FROM measurements WHERE deleted_at IS NULL ORDER BY local_date DESC, logged_at DESC LIMIT ?', [limit]);
  return rows.map((r) => ({
    id: r.id as string, localDate: r.local_date as string, type: r.type as string, value: r.value as number, unit: r.unit as string,
    note: (r.note as string) ?? null, loggedAt: r.logged_at as string,
  }));
}

// ---------- Recovery ----------
export async function upsertRecovery(e: Omit<RecoveryEntry, 'id' | 'loggedAt'>): Promise<void> {
  const existing = (await db().query('SELECT id FROM recovery_entries WHERE local_date = ? AND source = ?', [e.localDate, e.source]))[0];
  if (existing) {
    await db().run(
      `UPDATE recovery_entries SET sleep_hours=?, sleep_quality=?, energy=?, soreness=?, recovery=?, stress=?, readiness=?, logged_at=? WHERE id=?`,
      [e.sleepHours, e.sleepQuality, e.energy, e.soreness, e.recovery, e.stress, e.readiness, nowIso(), existing.id as string],
    );
  } else {
    await db().run(
      `INSERT INTO recovery_entries(id, local_date, sleep_hours, sleep_quality, energy, soreness, recovery, stress, readiness, source, logged_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
      [uid(), e.localDate, e.sleepHours, e.sleepQuality, e.energy, e.soreness, e.recovery, e.stress, e.readiness, e.source, nowIso()],
    );
  }
}

export async function listRecovery(fromDate: string, toDate: string): Promise<RecoveryEntry[]> {
  const rows = await db().query('SELECT * FROM recovery_entries WHERE local_date BETWEEN ? AND ? ORDER BY local_date DESC', [fromDate, toDate]);
  return rows.map((r) => ({
    id: r.id as string, localDate: r.local_date as string, sleepHours: (r.sleep_hours as number) ?? null, sleepQuality: (r.sleep_quality as number) ?? null,
    energy: (r.energy as number) ?? null, soreness: (r.soreness as number) ?? null, recovery: (r.recovery as number) ?? null,
    stress: (r.stress as number) ?? null, readiness: (r.readiness as number) ?? null, source: r.source as RecoveryEntry['source'], loggedAt: r.logged_at as string,
  }));
}

// ---------- Reminders ----------
export const DEFAULT_REMINDERS: Omit<Reminder, 'id'>[] = [
  { type: 'workout', label: 'Planned workout', enabled: false, time: '07:00', days: [1, 2, 3, 4, 5, 6, 7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'missed-workout', label: 'Missed session check-in', enabled: false, time: '19:00', days: [1, 2, 3, 4, 5, 6, 7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'water', label: 'Water', enabled: false, time: null, days: [1, 2, 3, 4, 5, 6, 7], intervalMinutes: 120, windowStart: '08:00', windowEnd: '21:00', snoozedUntil: null },
  { type: 'meal', label: 'Meal logging', enabled: false, time: '13:30', days: [1, 2, 3, 4, 5, 6, 7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'movement', label: 'Movement break', enabled: false, time: null, days: [1, 2, 3, 4, 5], intervalMinutes: 90, windowStart: '10:00', windowEnd: '18:00', snoozedUntil: null },
  { type: 'cardio', label: 'Cardio or walk', enabled: false, time: '18:00', days: [2, 4, 6], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'bedtime', label: 'Bedtime', enabled: false, time: '22:30', days: [1, 2, 3, 4, 5, 6, 7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'measurement', label: 'Body measurements', enabled: false, time: '08:00', days: [7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'weekly-review', label: 'Weekly review', enabled: false, time: '18:00', days: [7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
  { type: 'block-review', label: 'Programme block review', enabled: false, time: '18:00', days: [7], intervalMinutes: null, windowStart: null, windowEnd: null, snoozedUntil: null },
];

export async function listReminders(): Promise<Reminder[]> {
  let rows = await db().query('SELECT * FROM reminders');
  if (rows.length === 0) {
    await db().batch(DEFAULT_REMINDERS.map((r) => ({
      sql: `INSERT INTO reminders(id, type, label, enabled, time, days_json, interval_minutes, window_start, window_end) VALUES(?,?,?,?,?,?,?,?,?)`,
      params: [uid(), r.type, r.label, 0, r.time, JSON.stringify(r.days), r.intervalMinutes, r.windowStart, r.windowEnd] as SqlValue[],
    })));
    rows = await db().query('SELECT * FROM reminders');
  }
  return rows.map((r) => ({
    id: r.id as string, type: r.type as Reminder['type'], label: r.label as string, enabled: b(r.enabled), time: (r.time as string) ?? null,
    days: JSON.parse(r.days_json as string), intervalMinutes: (r.interval_minutes as number) ?? null, windowStart: (r.window_start as string) ?? null,
    windowEnd: (r.window_end as string) ?? null, snoozedUntil: (r.snoozed_until as string) ?? null,
  }));
}

export async function saveReminder(r: Reminder): Promise<void> {
  await db().run('UPDATE reminders SET enabled=?, time=?, days_json=?, interval_minutes=?, window_start=?, window_end=?, snoozed_until=? WHERE id=?', [
    r.enabled ? 1 : 0, r.time, JSON.stringify(r.days), r.intervalMinutes, r.windowStart, r.windowEnd, r.snoozedUntil, r.id,
  ]);
}

// ---------- AI log, improvement requests ----------
export async function logAi(kind: string, mode: string, promptChars: number, response: string | null, status: string): Promise<void> {
  await db().run('INSERT INTO ai_log(id, kind, mode, prompt_chars, response, status, created_at) VALUES(?,?,?,?,?,?,?)', [
    uid(), kind, mode, promptChars, response, status, nowIso(),
  ]);
}

export interface ImprovementRequest {
  id: string; title: string; body: string; category: string; status: string; aiAnalysis: string | null; createdAt: string; updatedAt: string;
}

export async function addImprovementRequest(title: string, body: string, category: string): Promise<ImprovementRequest> {
  const now = nowIso();
  const r: ImprovementRequest = { id: uid(), title, body, category, status: 'submitted', aiAnalysis: null, createdAt: now, updatedAt: now };
  await db().run('INSERT INTO improvement_requests(id, title, body, category, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?)', [
    r.id, r.title, r.body, r.category, r.status, r.createdAt, r.updatedAt,
  ]);
  return r;
}

export async function updateImprovementRequest(id: string, patch: { status?: string; aiAnalysis?: string | null }): Promise<void> {
  const cur = (await db().query('SELECT * FROM improvement_requests WHERE id = ?', [id]))[0];
  if (!cur) return;
  await db().run('UPDATE improvement_requests SET status=?, ai_analysis=?, updated_at=? WHERE id=?', [
    patch.status ?? (cur.status as string), patch.aiAnalysis === undefined ? (cur.ai_analysis as string | null) : patch.aiAnalysis, nowIso(), id,
  ]);
}

export async function listImprovementRequests(): Promise<ImprovementRequest[]> {
  const rows = await db().query('SELECT * FROM improvement_requests ORDER BY created_at DESC');
  return rows.map((r) => ({
    id: r.id as string, title: r.title as string, body: r.body as string, category: r.category as string, status: r.status as string,
    aiAnalysis: (r.ai_analysis as string) ?? null, createdAt: r.created_at as string, updatedAt: r.updated_at as string,
  }));
}

// ---------- Data ownership ----------
export async function exportAll(): Promise<Record<string, Record<string, SqlValue>[]>> {
  return db().exportJson();
}

/** Delete all user data but keep built-in reference content. */
export async function deleteAllUserData(): Promise<void> {
  const tables = ['set_logs', 'exercise_logs', 'sessions', 'planned_workouts', 'programmes', 'personal_records', 'nutrition_entries',
    'saved_meals', 'hydration_entries', 'measurements', 'progress_photos', 'recovery_entries', 'reminders', 'wearable_connections',
    'wearable_samples', 'sync_history', 'ai_log', 'improvement_requests', 'programme_reviews', 'audit', 'goals', 'profile'];
  await db().batch([
    ...tables.map((t) => ({ sql: `DELETE FROM ${t}` })),
    { sql: `DELETE FROM exercises WHERE is_custom = 1` },
    { sql: `DELETE FROM foods WHERE is_custom = 1` },
    { sql: `DELETE FROM settings WHERE key NOT IN ('schema_version','content_version','content_seeded_at')` },
  ]);
}
