// Thin async SQL driver interface. Two implementations:
//  - native.ts  : @capacitor-community/sqlite on Android (the primary, persistent database)
//  - sqljs.ts   : sql.js (WASM) for the browser dev preview and for automated tests
export type SqlValue = string | number | null;

export interface SqlDriver {
  run(sql: string, params?: SqlValue[]): Promise<{ changes: number }>;
  query<T = Record<string, SqlValue>>(sql: string, params?: SqlValue[]): Promise<T[]>;
  /** Run several statements atomically. */
  batch(statements: { sql: string; params?: SqlValue[] }[]): Promise<void>;
  /** Export the whole database as a JSON-serialisable object (for backups). */
  exportJson(): Promise<Record<string, Record<string, SqlValue>[]>>;
  close(): Promise<void>;
}

export const SCHEMA_VERSION_KEY = 'schema_version';
