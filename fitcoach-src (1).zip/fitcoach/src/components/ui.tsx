import { useEffect, useState, type ReactNode } from 'react';
import { back, navigate, useRoute } from '../lib/router';

const PATHS: Record<string, string> = {
  home: 'M3 11l9-8 9 8v9a2 2 0 0 1-2 2h-4v-6H9v6H5a2 2 0 0 1-2-2z',
  dumbbell: 'M6 7v10M18 7v10M3 9v6M21 9v6M6 12h12',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  leaf: 'M5 19c0-8 5-13 14-14-1 9-6 14-14 14zM5 19l7-7',
  user: 'M12 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8zM4 21c0-4 4-6 8-6s8 2 8 6',
  back: 'M15 5l-7 7 7 7',
  chevron: 'M9 5l7 7-7 7',
  check: 'M5 12l4 4 10-10',
  drop: 'M12 3s-6 7-6 11a6 6 0 0 0 12 0c0-4-6-11-6-11z',
  activity: 'M3 12h4l3-7 4 14 3-7h4',
  moon: 'M20 14A8 8 0 1 1 10 4a6 6 0 0 0 10 10z',
  bell: 'M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 21h4',
  sparkle: 'M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z',
  watch: 'M7 6h10a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3zM9 6V3h6v3M9 18v3h6v-3',
  pause: 'M8 5v14M16 5v14',
  play: 'M8 5l12 7-12 7z',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  plus: 'M12 5v14M5 12h14',
  send: 'M5 12h14M13 6l6 6-6 6',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
  download: 'M12 3v12M6 11l6 6 6-6M4 21h16',
  ruler: 'M3 17l14-14 4 4L7 21zM8 12l2 2M11 9l2 2M14 6l2 2',
  swap: 'M4 7h13l-3-3M20 17H7l3 3',
  x: 'M6 6l12 12M18 6L6 18',
  info: 'M12 8h.01M11 12h1v4h1M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18z',
  clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
};

export function Icon({ name, size = 22, color = 'currentColor' }: { name: keyof typeof PATHS; size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={PATHS[name]} />
    </svg>
  );
}

export function TopBar({ title, backTo, right, sub }: { title: string; backTo?: string; right?: ReactNode; sub?: string }) {
  return (
    <div className="topbar">
      {backTo !== undefined && (
        <button className="icon-btn" aria-label="Back" onClick={() => (backTo ? navigate(backTo) : back())}>
          <Icon name="back" />
        </button>
      )}
      <div className="grow col">
        <h1>{title}</h1>
        {sub && <span className="small muted">{sub}</span>}
      </div>
      {right}
    </div>
  );
}

const TABS: { path: string; label: string; icon: keyof typeof PATHS }[] = [
  { path: '/', label: 'Home', icon: 'home' },
  { path: '/workouts', label: 'Workouts', icon: 'dumbbell' },
  { path: '/progress', label: 'Progress', icon: 'chart' },
  { path: '/nutrition', label: 'Nutrition', icon: 'leaf' },
  { path: '/profile', label: 'Profile', icon: 'user' },
];

export function TabBar() {
  const { path } = useRoute();
  return (
    <nav className="tabbar" aria-label="Main">
      {TABS.map((t) => {
        const on = t.path === '/' ? path === '/' : path.startsWith(t.path);
        return (
          <a key={t.path} href={'#' + t.path} className={on ? 'on' : ''} aria-current={on ? 'page' : undefined}>
            <Icon name={t.icon} />
            {t.label}
          </a>
        );
      })}
    </nav>
  );
}

export function Switch({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} className={'switch' + (on ? ' on' : '')} onClick={() => onChange(!on)}>
      <span />
    </button>
  );
}

export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="row between">
          <h2>{title}</h2>
          <button className="icon-btn ghost" aria-label="Close" onClick={onClose}><Icon name="x" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Ring({ value, max, label, center, sub, size = 120 }: { value: number; max: number; label: string; center: string; sub: string; size?: number }) {
  const r = 50, c = 2 * Math.PI * r;
  const pct = max > 0 ? Math.min(1, value / max) : 0;
  return (
    <svg viewBox="0 0 120 120" width={size} height={size} role="img" aria-label={label} style={{ flexShrink: 0 }}>
      <circle cx="60" cy="60" r={r} fill="none" stroke="#E2E8F0" strokeWidth="10" />
      <circle cx="60" cy="60" r={r} fill="none" stroke="#1D6AE5" strokeWidth="10" strokeLinecap="round" strokeDasharray={`${pct * c} ${c}`} transform="rotate(-90 60 60)" />
      <text x="60" y="58" textAnchor="middle" fontSize="20" fontWeight="700" fill="#0F172A">{center}</text>
      <text x="60" y="76" textAnchor="middle" fontSize="11" fill="#475569">{sub}</text>
    </svg>
  );
}

/** Single-series line chart with direct labels on first/last points and a tap/hover readout. */
export function LineChart({ points, unit, label, height = 150 }: { points: { x: string; y: number }[]; unit: string; label: string; height?: number }) {
  const [sel, setSel] = useState<number | null>(null);
  if (points.length === 0) return <div className="empty">No data yet</div>;
  const W = 320, H = height, L = 36, R = 12, T = 18, B = 26;
  const ys = points.map((p) => p.y);
  let min = Math.min(...ys), max = Math.max(...ys);
  if (max - min < 1) { min -= 1; max += 1; }
  const pad = (max - min) * 0.15; min -= pad; max += pad;
  const x = (i: number) => (points.length === 1 ? (L + W - R) / 2 : L + (i * (W - L - R)) / (points.length - 1));
  const y = (v: number) => T + ((max - v) * (H - T - B)) / (max - min);
  const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.y).toFixed(1)}`).join(' ');
  const ticks = [max - pad, (max + min) / 2, min + pad];
  const fmt = (v: number) => (Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(1));
  const s = sel ?? points.length - 1;
  return (
    <div className="col" style={{ gap: 6 }}>
      <svg viewBox={`0 0 ${W} ${H}`} className="chart" role="img" aria-label={label} onMouseLeave={() => setSel(null)}>
        {ticks.map((t, i) => (
          <g key={i}>
            <line x1={L} x2={W - R} y1={y(t)} y2={y(t)} stroke="#E2E8F0" />
            <text x={L - 6} y={y(t) + 4} textAnchor="end" fontSize="10" fill="#475569">{fmt(t)}</text>
          </g>
        ))}
        <path d={path} fill="none" stroke="#1D6AE5" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        {points.map((p, i) => (
          <g key={i}>
            <circle cx={x(i)} cy={y(p.y)} r={i === s ? 5 : 3.5} fill="#1D6AE5" stroke="#fff" strokeWidth="2" />
            <rect x={x(i) - 12} y={T} width={24} height={H - T - B} fill="transparent" onMouseEnter={() => setSel(i)} onClick={() => setSel(i)} />
          </g>
        ))}
        {points.length > 1 && [0, points.length - 1].map((i) => (
          <text key={i} x={x(i)} y={H - 8} textAnchor={i === 0 ? 'start' : 'end'} fontSize="10" fill="#475569">{points[i].x}</text>
        ))}
      </svg>
      <div className="small muted" aria-live="polite">{points[s].x}: <b style={{ color: 'var(--ink)' }}>{points[s].y} {unit}</b></div>
    </div>
  );
}

export function BarChart({ bars, target, label, unit }: { bars: { x: string; y: number }[]; target?: number; label: string; unit: string }) {
  const max = Math.max(target ?? 0, ...bars.map((b) => b.y), 1);
  return (
    <div className="col" style={{ gap: 6 }}>
      <div className="row" style={{ alignItems: 'flex-end', gap: 6, height: 70 }} role="img" aria-label={label}>
        {bars.map((b, i) => (
          <div key={i} className="col grow" style={{ alignItems: 'center', height: '100%', justifyContent: 'flex-end', gap: 4 }}>
            <div style={{ width: '100%', borderRadius: '4px 4px 0 0', background: target && b.y >= target ? '#1D6AE5' : '#9DBFF2', height: `${Math.round((b.y / max) * 52)}px` }} title={`${b.x}: ${b.y} ${unit}`} />
            <span className="tiny muted">{b.x}</span>
          </div>
        ))}
      </div>
      {target != null && <span className="tiny muted">Dark bars reach the target of {target} {unit}.</span>}
    </div>
  );
}

export function Toast({ msg }: { msg: string | null }) {
  if (!msg) return null;
  return <div className="toast" role="status">{msg}</div>;
}

export function Stepper({ value, onChange, step, min = 0, label, unit }: { value: number; onChange: (v: number) => void; step: number; min?: number; label: string; unit?: string }) {
  const round = (v: number) => Math.round(v * 100) / 100;
  return (
    <div className="stepper">
      <button type="button" aria-label={`Decrease ${label}`} onClick={() => onChange(Math.max(min, round(value - step)))}>−</button>
      <input aria-label={label} inputMode="decimal" value={value} onChange={(e) => { const v = parseFloat(e.target.value); if (!Number.isNaN(v)) onChange(Math.max(min, v)); else if (e.target.value === '') onChange(0); }} />
      <button type="button" aria-label={`Increase ${label}`} onClick={() => onChange(round(value + step))}>+</button>
      {unit && <span className="small muted" style={{ width: 24 }}>{unit}</span>}
    </div>
  );
}
