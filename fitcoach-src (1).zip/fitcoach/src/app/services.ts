// Application services that combine repositories and engines.
import * as repo from '../db/repos';
import type { GoalId, PlannedWorkout, Profile, SetLog, Goal, Session } from '../db/types';
import { generateProgramme, TRAINING_WEEKDAYS } from '../engine/programme';
import { suggestLoad, detectPersonalRecords, volumeKg } from '../engine/progression';
import { buildWeeklyReview, type WeeklyReview } from '../engine/review';
import { hydrationTargetMl } from '../engine/targets';
import { addDays, localDate, diffDays } from '../lib/time';

export async function createProgrammeFromProfile(profile: Profile, goal: GoalId, startDate = localDate()): Promise<{ warnings: string[] }> {
  const exercises = await repo.listExercises();
  const weekdaysRaw = await repo.getSetting('training_weekdays');
  const trainingWeekdays = weekdaysRaw ? (JSON.parse(weekdaysRaw) as number[]) : undefined;
  const r = generateProgramme({ profile, goal, exercises, startDate, trainingWeekdays: trainingWeekdays?.length === profile.daysPerWeek ? trainingWeekdays : undefined });
  await repo.saveProgramme(r.programme, r.workouts);
  return { warnings: r.warnings };
}

/** Attach load suggestions (from history) to a planned workout for preview. */
export async function withSuggestions(w: PlannedWorkout): Promise<PlannedWorkout> {
  const exs = await repo.getExercisesByIds(w.exercises.map((e) => e.exerciseId));
  const lastSession = (await repo.listSessions(1))[0];
  const out = { ...w, exercises: [] as PlannedWorkout['exercises'] };
  for (const e of w.exercises) {
    const ex = exs.get(e.exerciseId);
    if (!ex) { out.exercises.push(e); continue; }
    const hist = await repo.exerciseHistory(e.exerciseId, 60);
    const last = hist.length ? hist.filter((s) => s.sessionId === hist[0].sessionId) : [];
    const prevSessionId = hist.find((s) => s.sessionId !== hist[0]?.sessionId)?.sessionId;
    const prev = prevSessionId ? hist.filter((s) => s.sessionId === prevSessionId) : [];
    const sug = suggestLoad(ex, e.repMin, e.repMax, last, prev, lastSession?.rpe ?? null, null);
    out.exercises.push({ ...e, suggestedKg: sug.kg, suggestionReason: sug.reason });
  }
  return out;
}

export interface SessionReport {
  session: Session;
  exercises: { name: string; exerciseId: string; planned: number; done: number; sets: SetLog[]; skipped: boolean; substitutedFrom: string | null; painReported: boolean }[];
  totalPlannedSets: number;
  totalDoneSets: number;
  volumeKg: number;
  newRecords: { exerciseName: string; type: string; weightKg: number; reps: number; value: number }[];
  previous: { exerciseId: string; bestWeight: number; bestReps: number } | null;
}

export async function finishAndReport(sessionId: string, status: 'completed' | 'abandoned', rpe: number | null, notes: string | null): Promise<SessionReport> {
  const session = await repo.finishSession(sessionId, status, rpe, notes);
  const logs = await repo.listExerciseLogs(sessionId);
  const sets = await repo.listSetLogs(sessionId);
  const exs = await repo.getExercisesByIds(logs.map((l) => l.exerciseId));
  const newRecords: SessionReport['newRecords'] = [];
  const report: SessionReport = { session, exercises: [], totalPlannedSets: 0, totalDoneSets: 0, volumeKg: 0, newRecords, previous: null };
  for (const l of logs) {
    const mine = sets.filter((s) => s.exerciseLogId === l.id);
    const done = mine.filter((s) => s.completed);
    report.totalPlannedSets += l.plannedSets;
    report.totalDoneSets += done.length;
    report.volumeKg += volumeKg(mine);
    report.exercises.push({ name: exs.get(l.exerciseId)?.name ?? l.exerciseId, exerciseId: l.exerciseId, planned: l.plannedSets, done: done.length, sets: done, skipped: l.skipped, substitutedFrom: l.substitutedFrom, painReported: l.painReported });
    if (status === 'completed' && done.length) {
      const byExercise = new Map<string, SetLog[]>();
      for (const s of done) { if (!byExercise.has(s.exerciseId)) byExercise.set(s.exerciseId, []); byExercise.get(s.exerciseId)!.push(s); }
      for (const [exId, exSets] of byExercise) {
        const existing = await repo.listPersonalRecords(exId);
        const prs = detectPersonalRecords(exId, exSets, existing);
        const exName = (exs.get(exId) ?? (await repo.getExercise(exId)))?.name ?? exId;
        for (const pr of prs) {
          await repo.insertPersonalRecord(pr);
          newRecords.push({ exerciseName: exName, type: pr.type, weightKg: pr.weightKg, reps: pr.reps, value: pr.value });
        }
      }
    }
  }
  report.volumeKg = Math.round(report.volumeKg);
  return report;
}

export async function reportFor(sessionId: string): Promise<SessionReport | null> {
  const session = await repo.getSession(sessionId);
  if (!session) return null;
  const logs = await repo.listExerciseLogs(sessionId);
  const sets = await repo.listSetLogs(sessionId);
  const exs = await repo.getExercisesByIds(logs.map((l) => l.exerciseId));
  const prs = (await repo.listPersonalRecords()).filter((p) => sets.some((s) => s.id === p.setLogId));
  const report: SessionReport = { session, exercises: [], totalPlannedSets: 0, totalDoneSets: 0, volumeKg: 0, newRecords: [], previous: null };
  for (const l of logs) {
    const mine = sets.filter((s) => s.exerciseLogId === l.id);
    const done = mine.filter((s) => s.completed);
    report.totalPlannedSets += l.plannedSets;
    report.totalDoneSets += done.length;
    report.volumeKg += volumeKg(mine);
    report.exercises.push({ name: exs.get(l.exerciseId)?.name ?? l.exerciseId, exerciseId: l.exerciseId, planned: l.plannedSets, done: done.length, sets: done, skipped: l.skipped, substitutedFrom: l.substitutedFrom, painReported: l.painReported });
  }
  report.newRecords = prs.map((p) => ({ exerciseName: exs.get(p.exerciseId)?.name ?? p.exerciseId, type: p.type, weightKg: p.weightKg, reps: p.reps, value: p.value }));
  report.volumeKg = Math.round(report.volumeKg);
  return report;
}

export async function computeWeeklyReview(weekEnd = localDate()): Promise<WeeklyReview> {
  const weekStart = addDays(weekEnd, -6);
  const prevStart = addDays(weekStart, -7);
  const programme = await repo.getActiveProgramme();
  const planned = programme ? (await repo.listPlannedWorkouts(programme.id)).filter((w) => w.scheduledDate >= weekStart && w.scheduledDate <= weekEnd) : [];
  const sessions = (await repo.listSessions(200)).filter((s) => s.status === 'completed' && localDate(new Date(s.startedAt)) >= weekStart && localDate(new Date(s.startedAt)) <= weekEnd);
  const prevSessions = (await repo.listSessions(200)).filter((s) => s.status === 'completed' && localDate(new Date(s.startedAt)) >= prevStart && localDate(new Date(s.startedAt)) < weekStart);
  const sets: SetLog[] = [];
  for (const s of sessions) sets.push(...(await repo.listSetLogs(s.id)).filter((x) => x.completed));
  const previousSets: SetLog[] = [];
  for (const s of prevSessions) previousSets.push(...(await repo.listSetLogs(s.id)).filter((x) => x.completed));
  const profile = await repo.getProfile();
  const hydrationTarget = Number((await repo.getSetting('hydration_target_ml')) ?? hydrationTargetMl(profile).ml);
  const exercises = await repo.getExercisesByIds([...sets, ...previousSets].map((s) => s.exerciseId));
  return buildWeeklyReview({
    weekStart, weekEnd, planned, sessions, sets, previousSets,
    recovery: await repo.listRecovery(weekStart, weekEnd),
    hydration: (await repo.hydrationDailyTotals(weekStart, weekEnd)).map((h) => ({ date: h.date, ml: h.ml })),
    hydrationTargetMl: hydrationTarget,
    nutrition: profile.nutritionEnabled ? await repo.nutritionDailyTotals(weekStart, weekEnd) : null,
    measurements: (await repo.listMeasurements(undefined, 200)).filter((m) => diffDays(m.localDate, weekEnd) <= 35),
    exercises,
  });
}

export function trainingWeekdaysFor(daysPerWeek: number): number[] {
  return TRAINING_WEEKDAYS[Math.min(6, Math.max(2, daysPerWeek))];
}

export async function goalFor(): Promise<Goal | null> {
  return repo.getActiveGoal();
}
