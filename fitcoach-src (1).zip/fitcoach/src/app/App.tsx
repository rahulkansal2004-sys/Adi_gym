import { useEffect } from 'react';
import { useRoute, navigate } from '../lib/router';
import { useApp } from './store';
import { TabBar, Toast } from '../components/ui';
import { Onboarding } from '../screens/Onboarding';
import { Home } from '../screens/Home';
import { Workouts } from '../screens/Workouts';
import { WorkoutPreview } from '../screens/WorkoutPreview';
import { ActiveSession } from '../screens/ActiveSession';
import { SessionSummary } from '../screens/SessionSummary';
import { Progress } from '../screens/Progress';
import { Nutrition } from '../screens/Nutrition';
import { Hydration } from '../screens/Hydration';
import { Measurements } from '../screens/Measurements';
import { Recovery } from '../screens/Recovery';
import { Coach } from '../screens/Coach';
import { Profile } from '../screens/Profile';
import { Reminders } from '../screens/Reminders';
import { Devices } from '../screens/Devices';
import { ImproveApp } from '../screens/ImproveApp';
import { ExerciseDetail, ExerciseLibrary } from '../screens/Exercises';
import { PrivacyCentre } from '../screens/Privacy';
import { EditProfile } from '../screens/EditProfile';
import { Reschedule } from '../screens/Reschedule';
import { WeeklyReviewScreen } from '../screens/WeeklyReview';

const TAB_ROOTS = ['/', '/workouts', '/progress', '/nutrition', '/profile', '/hydration', '/measurements', '/recovery', '/coach', '/exercises', '/reminders', '/devices', '/improve', '/privacy'];

export function App() {
  const { path, segments, query } = useRoute();
  const { profile, toastMsg } = useApp();

  useEffect(() => {
    if (!profile.onboardingComplete && !path.startsWith('/onboarding')) navigate('/onboarding', true);
  }, [profile.onboardingComplete, path]);

  if (!profile.onboardingComplete) return <><Onboarding /><Toast msg={toastMsg} /></>;

  const showTabs = TAB_ROOTS.includes(path) || path.startsWith('/exercises');
  let screen: React.ReactNode;
  switch (segments[0]) {
    case undefined: screen = <Home />; break;
    case 'workouts': screen = <Workouts />; break;
    case 'workout': screen = <WorkoutPreview id={segments[1]} />; break;
    case 'session': screen = <ActiveSession id={segments[1]} />; break;
    case 'summary': screen = <SessionSummary id={segments[1]} />; break;
    case 'progress': screen = <Progress />; break;
    case 'nutrition': screen = <Nutrition />; break;
    case 'hydration': screen = <Hydration />; break;
    case 'measurements': screen = <Measurements />; break;
    case 'recovery': screen = <Recovery />; break;
    case 'coach': screen = <Coach />; break;
    case 'review': screen = <WeeklyReviewScreen />; break;
    case 'profile': screen = <Profile />; break;
    case 'edit-profile': screen = <EditProfile section={segments[1] ?? 'profile'} />; break;
    case 'reminders': screen = <Reminders />; break;
    case 'devices': screen = <Devices />; break;
    case 'improve': screen = <ImproveApp />; break;
    case 'privacy': screen = <PrivacyCentre />; break;
    case 'reschedule': screen = <Reschedule />; break;
    case 'exercises': screen = segments[1] ? <ExerciseDetail id={segments[1]} query={query} /> : <ExerciseLibrary />; break;
    case 'onboarding': screen = <Home />; break;
    default: screen = <div className="screen"><h1>Not found</h1><a href="#/">Go home</a></div>;
  }
  return (
    <>
      {screen}
      {showTabs && <TabBar />}
      <Toast msg={toastMsg} />
    </>
  );
}
