import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Profile, GoalId } from '../db/types';
import type { Equipment, BodyArea } from '../data/exercises';
import { TopBar, Switch } from '../components/ui';
import { GOAL_INFO } from '../engine/programme';
import { createProgrammeFromProfile } from '../app/services';
import { loadAiConfig, saveAiConfig, setDirectApiKey, hasDirectApiKey, testAiConnection, type AiConfig } from '../ai/gemini';
import { navigate } from '../lib/router';

const ALL_EQUIPMENT: Equipment[] = ['barbell', 'dumbbell', 'cable', 'machine', 'bench', 'pull-up-bar', 'kettlebell', 'band', 'cardio-machine'];
const AREAS: BodyArea[] = ['knee', 'lower-back', 'shoulder', 'wrist', 'elbow', 'hip', 'neck', 'ankle'];
const PROGRAMME_FIELDS: (keyof Profile)[] = ['daysPerWeek', 'sessionMinutes', 'equipment', 'experience', 'restrictions', 'excludeGluteIsolation', 'location'];

export function EditProfile({ section }: { section: string }) {
  const { profile, goal, programme, refresh, toast } = useApp();
  const [p, setP] = useState<Profile>({ ...profile });
  const [primary, setPrimary] = useState<GoalId>(goal?.primaryGoal ?? 'general-health');
  const [secondary, setSecondary] = useState<GoalId | null>(goal?.secondaryGoal ?? null);
  const [customText, setCustomText] = useState(goal?.customText ?? '');
  const [busy, setBusy] = useState(false);
  const set = (patch: Partial<Profile>) => setP((x) => ({ ...x, ...patch }));

  const title = { profile: 'Edit profile', goal: 'Training goal', training: 'Training setup', health: 'Health and restrictions', preferences: 'Preferences', ai: 'AI coach' }[section] ?? 'Profile';

  async function save() {
    setBusy(true);
    try {
      const changedProgrammeFields = PROGRAMME_FIELDS.filter((k) => JSON.stringify(p[k]) !== JSON.stringify(profile[k]));
      const goalChanged = section === 'goal' && (primary !== goal?.primaryGoal || secondary !== (goal?.secondaryGoal ?? null));
      const saved = await repo.saveProfile({ ...p, restrictionsConfirmedAt: section === 'health' ? new Date().toISOString() : p.restrictionsConfirmedAt });
      if (section === 'goal') await repo.setGoal(primary, secondary, primary === 'custom' ? customText : null);
      if ((changedProgrammeFields.length > 0 || goalChanged) && programme) {
        const ok = confirm(`${goalChanged ? 'Your goal changed. ' : ''}${changedProgrammeFields.length ? 'Training setup changed (' + changedProgrammeFields.join(', ') + '). ' : ''}Rebuild the remaining programme from today? Completed sessions and records are kept; remaining planned sessions are replaced.`);
        if (ok) {
          const r = await createProgrammeFromProfile(saved, section === 'goal' ? primary : (goal?.primaryGoal ?? 'general-health'));
          for (const w of r.warnings) toast(w);
          toast('Programme rebuilt');
        } else toast('Saved. Programme unchanged until you rebuild it.');
      } else if (!programme && (section === 'training' || section === 'goal')) {
        await createProgrammeFromProfile(saved, section === 'goal' ? primary : (goal?.primaryGoal ?? 'general-health'));
        toast('Programme created');
      } else toast('Saved');
      await refresh();
      navigate('/profile');
    } catch (e) { toast((e as Error).message); } finally { setBusy(false); }
  }

  if (section === 'ai') return <AiSettings />;

  return (
    <div className="screen no-tabs">
      <TopBar title={title} backTo="/profile" />
      {section === 'profile' && (
        <>
          <div className="field"><label htmlFor="n">Name</label><input id="n" className="input" value={p.name ?? ''} onChange={(e) => set({ name: e.target.value || null })} /></div>
          <div className="field"><label htmlFor="d">Date of birth</label><input id="d" type="date" className="input" value={p.dob ?? ''} onChange={(e) => set({ dob: e.target.value || null })} /></div>
          <div className="grid2">
            <div className="field"><label htmlFor="h">Height (cm)</label><input id="h" type="number" inputMode="decimal" className="input" value={p.heightCm ?? ''} onChange={(e) => set({ heightCm: e.target.value ? Number(e.target.value) : null })} /></div>
            <div className="field"><label htmlFor="w">Weight (kg)</label><input id="w" type="number" inputMode="decimal" className="input" value={p.weightKg ?? ''} onChange={(e) => set({ weightKg: e.target.value ? Number(e.target.value) : null })} /></div>
            <div className="field"><label htmlFor="tw">Target weight</label><input id="tw" type="number" inputMode="decimal" className="input" value={p.targetWeightKg ?? ''} onChange={(e) => set({ targetWeightKg: e.target.value ? Number(e.target.value) : null })} /></div>
            <div className="field"><label htmlFor="wa">Waist (cm)</label><input id="wa" type="number" inputMode="decimal" className="input" value={p.waistCm ?? ''} onChange={(e) => set({ waistCm: e.target.value ? Number(e.target.value) : null })} /></div>
          </div>
          <div className="field"><label htmlFor="sex">Sex (optional)</label><select id="sex" className="input" value={p.sex ?? ''} onChange={(e) => set({ sex: (e.target.value || null) as Profile['sex'] })}><option value="">Not specified</option><option value="male">Male</option><option value="female">Female</option><option value="unspecified">Prefer not to say</option></select></div>
          <div className="field"><label htmlFor="exp">Training experience</label><select id="exp" className="input" value={p.experience} onChange={(e) => set({ experience: e.target.value as Profile['experience'] })}><option value="new">Complete beginner</option><option value="beginner-some">Beginner with some experience</option><option value="intermediate">Intermediate</option><option value="advanced">Advanced</option><option value="unsure">Unsure</option></select></div>
          <div className="field"><label htmlFor="act">Activity level</label><select id="act" className="input" value={p.activityLevel} onChange={(e) => set({ activityLevel: e.target.value as Profile['activityLevel'] })}><option value="sedentary">Sedentary</option><option value="light">Light</option><option value="moderate">Moderate</option><option value="active">Active</option><option value="very-active">Very active</option></select></div>
          <span className="tiny muted">Weight changes are also logged as a measurement. Changing experience rebuilds the remaining programme (with confirmation).</span>
        </>
      )}
      {section === 'goal' && (
        <>
          <p className="small muted">Changing the goal updates future recommendations only; your history and records are kept.</p>
          <div className="field"><label>Primary goal</label>
            <div className="stack">
              {(Object.keys(GOAL_INFO) as GoalId[]).map((g) => (
                <button key={g} className={'choice left' + (primary === g ? ' on' : '')} style={{ minHeight: 56 }} aria-pressed={primary === g} onClick={() => { setPrimary(g); if (secondary === g) setSecondary(null); }}>
                  <div className="col grow" style={{ textAlign: 'left' }}><span style={{ color: 'var(--ink)', fontWeight: 600 }}>{GOAL_INFO[g].label}</span><span className="tiny muted">{GOAL_INFO[g].blurb}</span></div>
                </button>
              ))}
            </div>
          </div>
          <div className="field"><label htmlFor="sec">Secondary goal (optional)</label>
            <select id="sec" className="input" value={secondary ?? ''} onChange={(e) => setSecondary((e.target.value || null) as GoalId | null)}>
              <option value="">None</option>
              {(Object.keys(GOAL_INFO) as GoalId[]).filter((g) => g !== primary && g !== 'custom').map((g) => <option key={g} value={g}>{GOAL_INFO[g].label}</option>)}
            </select>
          </div>
          {primary === 'custom' && <input className="input" aria-label="Custom goal" value={customText} onChange={(e) => setCustomText(e.target.value)} placeholder="Describe your goal" />}
        </>
      )}
      {section === 'training' && (
        <>
          <div className="field"><label>Days per week</label><div className="grid5">{[2, 3, 4, 5, 6].map((n) => <button key={n} className={'choice' + (p.daysPerWeek === n ? ' on' : '')} aria-pressed={p.daysPerWeek === n} onClick={() => set({ daysPerWeek: n })}>{n}</button>)}</div></div>
          <div className="field"><label>Session length</label><div className="grid4">{[30, 45, 60, 75].map((n) => <button key={n} className={'choice' + (p.sessionMinutes === n ? ' on' : '')} aria-pressed={p.sessionMinutes === n} onClick={() => set({ sessionMinutes: n })}>{n} min</button>)}</div></div>
          <div className="field"><label>Where you train</label><div className="grid3">{(['gym', 'home', 'both'] as const).map((l) => <button key={l} className={'choice' + (p.location === l ? ' on' : '')} aria-pressed={p.location === l} onClick={() => set({ location: l })}>{l}</button>)}</div></div>
          <div className="field"><label>Equipment available</label><div className="grid3">{ALL_EQUIPMENT.map((q) => { const on = p.equipment.includes(q); return <button key={q} className={'choice' + (on ? ' on' : '')} style={{ fontSize: 12, padding: '0 4px' }} aria-pressed={on} onClick={() => set({ equipment: on ? p.equipment.filter((x) => x !== q) : [...p.equipment, q] })}>{q}</button>; })}</div><span className="tiny muted">Bodyweight is always available.</span></div>
          <label className="row card flat" style={{ cursor: 'pointer' }}><input type="checkbox" checked={p.excludeGluteIsolation} onChange={(e) => set({ excludeGluteIsolation: e.target.checked })} /><span className="grow small">Skip dedicated glute-isolation exercises</span></label>
          <a href="#/reschedule" className="btn secondary md">Choose training weekdays / reschedule</a>
        </>
      )}
      {section === 'health' && (
        <>
          <p className="small muted">Are these restrictions still current? Saving confirms them as of today{profile.restrictionsConfirmedAt ? ` (last confirmed ${profile.restrictionsConfirmedAt.slice(0, 10)})` : ''}. Exercises that load a listed area are excluded from your plan and substitutions.</p>
          <div className="grid4">{AREAS.map((a) => { const on = p.restrictions.includes(a); return <button key={a} className={'choice' + (on ? ' on' : '')} style={{ fontSize: 13, padding: '0 4px' }} aria-pressed={on} onClick={() => set({ restrictions: on ? p.restrictions.filter((x) => x !== a) : [...p.restrictions, a] })}>{a.replace('-', ' ')}</button>; })}</div>
          <textarea className="input" aria-label="Notes" placeholder="Notes for yourself (e.g. physio advice)" value={p.restrictionNotes ?? ''} onChange={(e) => set({ restrictionNotes: e.target.value || null })} />
          <div className="field"><label htmlFor="sl">Usual sleep (hours)</label><input id="sl" type="number" inputMode="decimal" className="input" value={p.sleepHours ?? ''} onChange={(e) => set({ sleepHours: e.target.value ? Number(e.target.value) : null })} /></div>
          <div className="card warn small">This app does not diagnose or treat anything. If you have a medical condition, are pregnant, or have been told to limit exercise or fluids, follow your clinician's advice over any suggestion here.</div>
        </>
      )}
      {section === 'preferences' && (
        <>
          <div className="field"><label htmlFor="diet">Diet</label><select id="diet" className="input" value={p.diet} onChange={(e) => set({ diet: e.target.value as Profile['diet'] })}><option value="vegetarian">Vegetarian (includes dairy)</option><option value="eggetarian">Vegetarian + eggs</option><option value="non-vegetarian">Non-vegetarian</option><option value="vegan">Vegan</option></select></div>
          <div className="row between card flat"><div className="col"><b style={{ fontSize: 14 }}>Nutrition tracking</b><span className="tiny muted">Optional. Hides the Nutrition tab's logging when off.</span></div><Switch on={p.nutritionEnabled} onChange={(v) => set({ nutritionEnabled: v })} label="Nutrition tracking" /></div>
          <div className="grid3">
            <div className="field"><label htmlFor="uw">Weight unit</label><select id="uw" className="input" value={p.unitsWeight} onChange={(e) => set({ unitsWeight: e.target.value as Profile['unitsWeight'] })}><option value="kg">kg</option><option value="lb">lb (display only)</option></select></div>
            <div className="field"><label htmlFor="ul">Length</label><select id="ul" className="input" value={p.unitsLength} onChange={(e) => set({ unitsLength: e.target.value as Profile['unitsLength'] })}><option value="cm">cm</option><option value="in">in (display only)</option></select></div>
            <div className="field"><label htmlFor="uv">Volume</label><select id="uv" className="input" value={p.unitsVolume} onChange={(e) => set({ unitsVolume: e.target.value as Profile['unitsVolume'] })}><option value="ml">ml</option><option value="floz">fl oz (display only)</option></select></div>
          </div>
          <span className="tiny muted">Data is stored in metric; imperial display is a known limitation in this version (values are still entered in kg/cm/ml). Time zone: {Intl.DateTimeFormat().resolvedOptions().timeZone}.</span>
        </>
      )}
      <button className="btn" disabled={busy} onClick={save}>{busy ? 'Saving…' : 'Save'}</button>
    </div>
  );
}

function AiSettings() {
  const { toast } = useApp();
  const [cfg, setCfg] = useState<AiConfig | null>(null);
  const [key, setKey] = useState('');
  const [hasKey, setHasKey] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  useEffect(() => { void loadAiConfig().then(setCfg); void hasDirectApiKey().then(setHasKey); }, []);
  if (!cfg) return null;
  async function save() {
    await saveAiConfig(cfg!);
    if (key.trim()) { await setDirectApiKey(key.trim()); setHasKey(true); setKey(''); }
    toast('AI settings saved');
  }
  async function test() {
    await saveAiConfig(cfg!);
    if (key.trim()) { await setDirectApiKey(key.trim()); setHasKey(true); setKey(''); }
    setResult('Testing…');
    const r = await testAiConnection();
    setResult(r.ok ? `Connected (${r.mode}). Reply: ${r.text.slice(0, 40)}` : `${r.reason}: ${r.message}`);
  }
  return (
    <div className="screen no-tabs">
      <TopBar title="AI coach (Gemini)" backTo="/profile" />
      <div className="card small" style={{ lineHeight: '18px' }}>
        <b>Where does the key live?</b>
        <span>The APK contains no key. A key embedded in an app can be extracted, so FitCoach never does that. Pick one:</span>
        <span><b>Proxy (recommended for home testing):</b> run <code>node gemini-proxy/server.mjs</code> on your computer; the key stays in that computer's <code>.env</code>. The phone talks to the proxy over Wi-Fi.</span>
        <span><b>Direct:</b> type the key here. It is stored in the app's private storage on this phone (not in the APK, not readable by other apps on an unrooted phone), but anyone with full device access or a backup extract could read it. Restrict the key in Google AI Studio to the Generative Language API and keep a quota cap.</span>
      </div>
      <div className="grid3">{(['off', 'proxy', 'direct'] as const).map((m) => <button key={m} className={'choice' + (cfg.mode === m ? ' on' : '')} aria-pressed={cfg.mode === m} onClick={() => setCfg({ ...cfg, mode: m })}>{m}</button>)}</div>
      {cfg.mode === 'proxy' && (
        <>
          <div className="field"><label htmlFor="purl">Proxy address</label><input id="purl" className="input" placeholder="http://192.168.1.10:8787" value={cfg.proxyUrl} onChange={(e) => setCfg({ ...cfg, proxyUrl: e.target.value.trim() })} /></div>
          <div className="field"><label htmlFor="ptok">Proxy token (if set in .env)</label><input id="ptok" className="input" value={cfg.proxyToken} onChange={(e) => setCfg({ ...cfg, proxyToken: e.target.value.trim() })} /></div>
          <span className="tiny muted">Phone and computer must be on the same Wi-Fi. The proxy prints its address when it starts.</span>
        </>
      )}
      {cfg.mode === 'direct' && (
        <div className="field"><label htmlFor="key">Gemini API key {hasKey && <span className="pill good" style={{ fontSize: 10 }}>saved on device</span>}</label><input id="key" className="input" type="password" placeholder={hasKey ? 'Enter a new key to replace' : 'AIza…'} value={key} onChange={(e) => setKey(e.target.value)} autoComplete="off" />
          {hasKey && <button className="btn ghost sm" onClick={async () => { await setDirectApiKey(null); setHasKey(false); toast('Key removed'); }}>Remove saved key</button>}</div>
      )}
      <div className="grid2">
        <div className="field"><label htmlFor="model">Model</label><input id="model" className="input" value={cfg.model} onChange={(e) => setCfg({ ...cfg, model: e.target.value.trim() })} /></div>
        <div className="field"><label htmlFor="cap">Monthly call cap</label><input id="cap" className="input" type="number" value={cfg.monthlyCallCap} onChange={(e) => setCfg({ ...cfg, monthlyCallCap: Number(e.target.value) || 0 })} /></div>
      </div>
      {result && <div className="card flat small">{result}</div>}
      <div className="row"><button className="btn secondary md" onClick={test}>Test connection</button><button className="btn md" onClick={save}>Save</button></div>
      <span className="tiny muted">If Gemini is offline, out of quota or disabled, every coaching screen falls back to deterministic text from your data.</span>
    </div>
  );
}
