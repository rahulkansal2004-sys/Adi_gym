import { useEffect, useRef, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import { chat } from '../ai/coach';
import { loadAiConfig, type AiConfig } from '../ai/gemini';
import { Icon, TopBar } from '../components/ui';
import { computeWeeklyReview } from '../app/services';

interface Msg { who: 'me' | 'ai'; text: string; note?: string | null }

export function Coach() {
  const { profile, goal } = useApp();
  const [cfg, setCfg] = useState<AiConfig | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { void loadAiConfig().then(setCfg); }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [msgs]);

  async function send(q: string) {
    if (!q.trim() || busy) return;
    setMsgs((m) => [...m, { who: 'me', text: q }]);
    setInput(''); setBusy(true);
    const review = await computeWeeklyReview();
    const last = (await repo.listSessions(3)).map((s) => ({ name: s.name, date: s.startedAt.slice(0, 10), durationMin: s.durationS ? Math.round(s.durationS / 60) : null, rpe: s.rpe }));
    const a = await chat(q, { weekSummary: review.summary, strength: review.strength.slice(0, 5), recovery: review.recovery, hydration: review.hydration, recentSessions: last, dataGaps: review.dataGaps }, profile, goal);
    setMsgs((m) => [...m, { who: 'ai', text: a.text, note: a.note }]);
    setBusy(false);
  }

  const quick = ['How did my last workout go?', 'What should I eat today for my goal?', 'Explain the bench press cues', 'I have less time this week'];

  return (
    <div className="screen" style={{ paddingBottom: 100 }}>
      <TopBar title="AI coach" backTo="/" sub="Gemini · general fitness guidance, not medical advice" right={<a href="#/review" className="btn secondary sm">Weekly review</a>} />
      {cfg && cfg.mode === 'off' && <div className="card warn small">AI coaching is off. Core features work without it. Turn it on in <a href="#/edit-profile/ai">Profile › AI coach</a> (your key stays off the APK: proxy on your computer, or typed into the app).</div>}
      {cfg && cfg.mode !== 'off' && <span className="tiny muted">Mode: {cfg.mode === 'proxy' ? `proxy at ${cfg.proxyUrl || '(not set)'}` : 'direct from this phone'} · model {cfg.model}. Only derived summaries are sent, never your name, date of birth or raw logs.</span>}
      <div className="stack" style={{ flex: 1 }}>
        {msgs.length === 0 && <div className="bubble ai">Hi. Ask about your training, nutrition or progress. I answer from your logged data and will say when something is missing.</div>}
        {msgs.map((m, i) => (
          <div key={i} className={'bubble ' + m.who}>
            {m.text}
            {m.note && <div className="tiny muted" style={{ marginTop: 6 }}>{m.note}</div>}
          </div>
        ))}
        {busy && <div className="bubble ai muted">Thinking…</div>}
        <div ref={endRef} />
      </div>
      <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
        {quick.map((q) => <button key={q} className="pill grey" style={{ border: 0, cursor: 'pointer', minHeight: 36 }} onClick={() => send(q)}>{q}</button>)}
      </div>
      <form className="row" onSubmit={(e) => { e.preventDefault(); void send(input); }}>
        <label htmlFor="msg" className="sr-only">Message the coach</label>
        <input id="msg" className="input grow" placeholder="Ask anything about your training" value={input} onChange={(e) => setInput(e.target.value)} />
        <button type="submit" className="icon-btn" style={{ background: 'var(--blue)', color: '#fff' }} aria-label="Send" disabled={busy}><Icon name="send" /></button>
      </form>
      <span className="tiny muted" style={{ textAlign: 'center' }}>Needs internet. Workouts, logs and hydration keep working offline.</span>
    </div>
  );
}
