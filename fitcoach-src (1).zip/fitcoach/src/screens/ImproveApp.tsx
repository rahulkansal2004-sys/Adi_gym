import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import { TopBar } from '../components/ui';
import { analyseImprovementRequest } from '../ai/coach';

const STATUSES = ['submitted', 'analysed', 'approved', 'planned', 'done', 'rejected'];

export function ImproveApp() {
  const { toast } = useApp();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [category, setCategory] = useState('feature');
  const [list, setList] = useState<repo.ImprovementRequest[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const reload = async () => setList(await repo.listImprovementRequests());
  useEffect(() => { void reload(); }, []);

  async function submit() {
    if (!title.trim() || !body.trim()) { toast('Add a title and a description'); return; }
    const r = await repo.addImprovementRequest(title.trim(), body.trim(), category);
    setTitle(''); setBody('');
    await reload();
    await analyse(r.id, r.title, r.body);
  }
  async function analyse(id: string, t: string, b: string) {
    setBusy(id);
    const a = await analyseImprovementRequest(t, b);
    if (a.source === 'ai') await repo.updateImprovementRequest(id, { status: 'analysed', aiAnalysis: a.text });
    else toast(a.note ?? 'AI unavailable; request saved');
    setBusy(null);
    await reload();
  }

  return (
    <div className="screen">
      <TopBar title="Improve my app" backTo="/profile" />
      <div className="card">
        <span className="small muted">Request a feature, report a bug or suggest a usability change. Requests are saved here; Gemini (when enabled) produces a proposal with impact and testing notes. No code is changed automatically: implementing a change is a separate development step with tests and a rollback (the previous APK).</span>
        <div className="grid3">{['feature', 'bug', 'usability'].map((c) => <button key={c} className={'choice' + (category === c ? ' on' : '')} style={{ minHeight: 40 }} aria-pressed={category === c} onClick={() => setCategory(c)}>{c}</button>)}</div>
        <input className="input" aria-label="Title" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea className="input" aria-label="Description" placeholder="What is missing, or what went wrong, and where in the app?" value={body} onChange={(e) => setBody(e.target.value)} />
        <button className="btn md" onClick={submit}>Submit request</button>
      </div>
      <div className="card">
        <b style={{ fontSize: 14 }}>Previous requests</b>
        {list.length === 0 && <span className="small muted">None yet.</span>}
        {list.map((r) => (
          <div key={r.id} className="col" style={{ gap: 6, paddingTop: 8, borderTop: '1px solid #F1F5F9' }}>
            <div className="row between"><b style={{ fontSize: 14 }}>{r.title}</b><span className={'pill ' + (r.status === 'done' ? 'good' : r.status === 'rejected' ? 'grey' : '')} style={{ fontSize: 10 }}>{r.status}</span></div>
            <span className="small muted">{r.category} · {r.createdAt.slice(0, 10)}</span>
            <span className="small" style={{ whiteSpace: 'pre-wrap' }}>{r.body}</span>
            {r.aiAnalysis && <div className="card soft small" style={{ whiteSpace: 'pre-wrap', lineHeight: '18px' }}><b>Proposal (AI)</b>{r.aiAnalysis}</div>}
            <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
              {!r.aiAnalysis && <button className="btn secondary sm" disabled={busy === r.id} onClick={() => analyse(r.id, r.title, r.body)}>{busy === r.id ? 'Analysing…' : 'Analyse with AI'}</button>}
              <select className="input" style={{ height: 40, width: 'auto', fontSize: 13 }} aria-label="Status" value={r.status} onChange={async (e) => { await repo.updateImprovementRequest(r.id, { status: e.target.value }); await reload(); }}>
                {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
