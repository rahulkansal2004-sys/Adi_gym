import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Exercise, PlannedWorkout } from '../db/types';
import { Icon, Sheet, TopBar } from '../components/ui';
import { withSuggestions } from '../app/services';
import { shortenWorkout } from '../engine/schedule';
import { navigate } from '../lib/router';

export function WorkoutPreview({ id }: { id?: string }) {
  const { inProgress, refresh, toast } = useApp();
  const [w, setW] = useState<PlannedWorkout | null>(null);
  const [exs, setExs] = useState<Map<string, Exercise>>(new Map());
  const [tab, setTab] = useState<'list' | 'warmup'>('list');
  const [shorten, setShorten] = useState(false);
  const [minutes, setMinutes] = useState(30);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      if (!id) return;
      const base = await repo.getPlannedWorkout(id);
      if (!base) return;
      const sug = await withSuggestions(base);
      setW(sug);
      setExs(await repo.getExercisesByIds(sug.exercises.map((e) => e.exerciseId)));
    })();
  }, [id]);

  if (!w) return <div className="screen no-tabs"><TopBar title="Workout" backTo="/workouts" /><div className="empty">Loading…</div></div>;
  const name = (eid: string) => exs.get(eid)?.name ?? eid;
  const short = shortenWorkout(w.exercises, minutes, name);
  const equipment = [...new Set(w.exercises.flatMap((e) => exs.get(e.exerciseId)?.equipment ?? []))].filter((q) => q !== 'bodyweight');

  async function start(exercises = w!.exercises) {
    if (inProgress) { navigate(`/session/${inProgress.id}`); return; }
    setBusy(true);
    try {
      const planned = { ...w!, exercises };
      const { session } = await repo.createSession(planned, w!.name);
      await refresh();
      navigate(`/session/${session.id}`, true);
    } catch (e) { toast((e as Error).message); setBusy(false); }
  }

  return (
    <div className="screen no-tabs">
      <TopBar title={w.scheduledDate ? w.name : 'Workout'} backTo="/workouts" right={<button className="btn secondary sm" onClick={() => setShorten(true)}>Less time?</button>} />
      <div className="card">
        <span className="small muted">Week {w.week} · {w.scheduledDate}</span>
        <span className="small" style={{ lineHeight: '18px', color: 'var(--ink-2)' }}>Objective: {w.focus}. Loads marked "suggested" come from your own logged sets; progress is suggested only when every set reached the top of the range last time.</span>
        <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
          <span className="pill">About {w.estimatedMinutes} min</span>
          <span className="pill">{w.exercises.length} exercises</span>
          {equipment.length > 0 && <span className="pill">{equipment.join(', ')}</span>}
        </div>
      </div>
      <div className="tabs" role="tablist">
        <button role="tab" aria-selected={tab === 'list'} className={tab === 'list' ? 'on' : ''} onClick={() => setTab('list')}>Exercise list</button>
        <button role="tab" aria-selected={tab === 'warmup'} className={tab === 'warmup' ? 'on' : ''} onClick={() => setTab('warmup')}>Warm-up (6 min)</button>
      </div>
      {tab === 'warmup' && (
        <div className="card small" style={{ lineHeight: '19px' }}>
          <b>General warm-up (3 min):</b> easy walking, cycling or marching on the spot until you feel warm.
          <b>Specific warm-up (3 min):</b> 1–2 lighter sets of the first main exercise (about 50% then 70% of the working load, 5–8 reps each). Mobility drills in today's list can be done here too.
          <span className="muted">The warm-up is never removed when a session is shortened.</span>
        </div>
      )}
      {tab === 'list' && (
        <ol className="stack" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
          {w.exercises.map((e, i) => {
            const ex = exs.get(e.exerciseId);
            return (
              <li key={i} className="card row" style={{ padding: '10px 12px' }}>
                <span className="icon-box sm" style={{ background: 'var(--surface)', color: 'var(--ink-2)', fontWeight: 700, fontSize: 13 }}>{i + 1}</span>
                <div className="col grow">
                  <b style={{ fontSize: 14 }}>{ex?.name ?? e.exerciseId}</b>
                  <span className="small muted">{e.durationMinutes ? `${e.durationMinutes} min` : `${e.sets} × ${e.repMin}–${e.repMax} · rest ${e.restSeconds} s`}{e.role === 'main' ? ' · main' : ''}</span>
                  {e.suggestionReason && <span className="tiny" style={{ color: 'var(--blue)' }}>{e.suggestedKg != null ? `${e.suggestedKg} kg suggested · ` : ''}{e.suggestionReason}</span>}
                </div>
                <a href={`#/exercises/${e.exerciseId}?from=workout`} className="icon-btn ghost" aria-label={`About ${ex?.name}`}><Icon name="chevron" size={18} color="#475569" /></a>
              </li>
            );
          })}
        </ol>
      )}
      <button className="btn" disabled={busy} onClick={() => start()}>{inProgress ? 'Resume current workout' : 'Start workout'}</button>

      <Sheet open={shorten} onClose={() => setShorten(false)} title="Shorter session">
        <p className="small muted">Pick how long you have. Accessories go first, then cardio minutes, then one set from secondary and main lifts. The warm-up and main movements stay.</p>
        <div className="grid4">
          {[20, 30, 40, 50].map((m) => <button key={m} className={'choice' + (minutes === m ? ' on' : '')} aria-pressed={minutes === m} onClick={() => setMinutes(m)}>{m} min</button>)}
        </div>
        <div className="card flat small">
          <b>Result: about {short.minutes} min, {short.exercises.length} exercises</b>
          {short.removed.length > 0 && <span>Removed: {short.removed.join(', ')}</span>}
          {short.reducedSets.length > 0 && <span>Reduced: {short.reducedSets.join(', ')}</span>}
          {short.removed.length === 0 && short.reducedSets.length === 0 && <span className="muted">Nothing needs cutting for this duration.</span>}
        </div>
        <button className="btn" onClick={() => start(short.exercises)}>Start shortened workout</button>
      </Sheet>
    </div>
  );
}
