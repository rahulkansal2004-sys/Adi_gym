import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { PlannedWorkout, Reminder } from '../db/types';
import { Icon } from '../components/ui';
import { hydrationTargetMl, calorieTarget } from '../engine/targets';
import { missedWorkouts } from '../engine/schedule';
import { localDate } from '../lib/time';
import { getConnection, daySummaries, type ConnectionState } from '../wearables/healthConnect';
import { navigate } from '../lib/router';

export function Home() {
  const { profile, goal, programme, inProgress } = useApp();
  const [next, setNext] = useState<PlannedWorkout | null>(null);
  const [missed, setMissed] = useState(0);
  const [water, setWater] = useState({ ml: 0, target: 2500 });
  const [kcal, setKcal] = useState<{ eaten: number; target: number | null; protein: number; proteinTarget: number | null } | null>(null);
  const [recent, setRecent] = useState<string | null>(null);
  const [recovery, setRecovery] = useState<string | null>(null);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [conn, setConn] = useState<ConnectionState | null>(null);
  const [steps, setSteps] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      const today = localDate();
      if (programme) {
        const all = await repo.listPlannedWorkouts(programme.id);
        setMissed(missedWorkouts(all, today).length);
        setNext(await repo.getNextPlannedWorkout(programme.id, today));
      }
      const hyd = await repo.listHydration(today);
      setWater({ ml: hyd.reduce((a, h) => a + h.amountMl, 0), target: Number((await repo.getSetting('hydration_target_ml')) ?? hydrationTargetMl(profile).ml) });
      if (profile.nutritionEnabled) {
        const n = await repo.listNutrition(today);
        const t = goal ? calorieTarget(profile, goal.primaryGoal) : null;
        setKcal({ eaten: Math.round(n.reduce((a, e) => a + e.kcal, 0)), target: t?.kcal ?? null, protein: Math.round(n.reduce((a, e) => a + e.protein, 0)), proteinTarget: t?.protein ?? null });
      }
      const prs = await repo.listPersonalRecords();
      if (prs[0]) {
        const ex = await repo.getExercise(prs[0].exerciseId);
        setRecent(`${ex?.name ?? prs[0].exerciseId}: ${prs[0].type === 'best-e1rm' ? `est. 1RM ${prs[0].value} kg` : `${prs[0].weightKg} kg × ${prs[0].reps}`} on ${prs[0].achievedAt.slice(0, 10)}`);
      }
      const rec = (await repo.listRecovery(today, today))[0];
      if (rec) setRecovery(`${rec.sleepHours != null ? `Sleep ${rec.sleepHours} h` : ''}${rec.soreness != null ? ` · soreness ${rec.soreness}/5` : ''}${rec.readiness != null ? ` · readiness ${rec.readiness}/5` : ''}`.replace(/^ · /, ''));
      setReminders((await repo.listReminders()).filter((r) => r.enabled));
      const c = await getConnection();
      setConn(c);
      if (c.status === 'connected') { const d = await daySummaries(1); setSteps(d[0]?.steps ?? null); }
    })();
  }, [programme, profile, goal, inProgress]);

  const greeting = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';
  const stepsTarget = Number(localStorage.getItem('steps_target') ?? 8000);

  return (
    <div className="screen">
      <div className="row between">
        <div className="col">
          <span className="small muted">{greeting}{profile.name ? `, ${profile.name}` : ''}</span>
          <h1>Let's build a stronger you</h1>
        </div>
        <a href="#/profile" className="avatar" aria-label="Profile and settings">{(profile.name ?? 'Me').slice(0, 2).toUpperCase()}</a>
      </div>

      {inProgress && (
        <div className="card soft">
          <div className="row"><Icon name="play" color="#1D6AE5" /><div className="col grow"><b>Workout in progress</b><span className="small muted">{inProgress.name} · started {new Date(inProgress.startedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div></div>
          <button className="btn md" onClick={() => navigate(`/session/${inProgress.id}`)}>Resume workout</button>
        </div>
      )}

      {!inProgress && next && (
        <div className="card">
          <div className="row">
            <div className="icon-box"><Icon name="dumbbell" /></div>
            <div className="col grow">
              <span className="small" style={{ color: 'var(--blue)', fontWeight: 600 }}>{next.scheduledDate === localDate() ? "Today's workout" : next.scheduledDate < localDate() ? `Overdue since ${next.scheduledDate}` : `Next: ${next.scheduledDate}`} · Week {next.week}</span>
              <b style={{ fontSize: 16 }}>{next.name}</b>
              <span className="small muted">{next.exercises.length} exercises · about {next.estimatedMinutes} min · {next.focus}</span>
            </div>
          </div>
          <button className="btn md" onClick={() => navigate(`/workout/${next.id}`)}>Preview and start</button>
          {missed > 0 && <a href="#/reschedule" className="small" style={{ fontWeight: 600 }}>{missed} missed session{missed > 1 ? 's' : ''}: reschedule, skip or defer</a>}
        </div>
      )}
      {!inProgress && !next && (
        <div className="card">
          <b>No planned workouts</b>
          <span className="small muted">{programme ? 'This block is complete. Review it and start the next one.' : 'Generate a programme from your profile to get started.'}</span>
          <button className="btn md" onClick={() => navigate(programme ? '/review' : '/edit-profile/training')}>{programme ? 'Review block' : 'Build programme'}</button>
        </div>
      )}

      <div className="grid2">
        <a href="#/hydration" className="card" style={{ color: 'inherit' }}>
          <span className="row small muted" style={{ fontWeight: 600 }}><Icon name="drop" size={16} color="#1D6AE5" />Water</span>
          <span style={{ fontSize: 22, fontWeight: 700 }}>{(water.ml / 1000).toFixed(1)} L <span className="small muted" style={{ fontWeight: 500 }}>/ {(water.target / 1000).toFixed(1)} L</span></span>
          <div className="progress"><div style={{ width: `${Math.min(100, (water.ml / water.target) * 100)}%` }} /></div>
          <span className="small muted">{water.ml >= water.target ? 'Target reached' : `${((water.target - water.ml) / 1000).toFixed(1)} L to go`}</span>
        </a>
        {conn?.status === 'connected' ? (
          <a href="#/devices" className="card" style={{ color: 'inherit' }}>
            <span className="row small muted" style={{ fontWeight: 600 }}><Icon name="activity" size={16} color="#1D6AE5" />Steps</span>
            {steps != null ? (
              <>
                <span style={{ fontSize: 22, fontWeight: 700 }}>{steps.toLocaleString()} <span className="small muted" style={{ fontWeight: 500 }}>/ {stepsTarget.toLocaleString()}</span></span>
                <div className="progress"><div style={{ width: `${Math.min(100, (steps / stepsTarget) * 100)}%` }} /></div>
              </>
            ) : <span className="small muted">No steps synced for today yet</span>}
            <span className="tiny muted">Health Connect · {conn.lastSyncAt ? `synced ${new Date(conn.lastSyncAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : 'not synced'}</span>
          </a>
        ) : (
          <a href="#/recovery" className="card" style={{ color: 'inherit' }}>
            <span className="row small muted" style={{ fontWeight: 600 }}><Icon name="moon" size={16} color="#1D6AE5" />Recovery</span>
            {recovery ? <span className="small">{recovery}</span> : <span className="small muted">No check-in today. Tap to log sleep and soreness.</span>}
            <span className="tiny muted">Manual entry</span>
          </a>
        )}
        {profile.nutritionEnabled && kcal && (
          <a href="#/nutrition" className="card" style={{ color: 'inherit' }}>
            <span className="row small muted" style={{ fontWeight: 600 }}><Icon name="leaf" size={16} color="#1D6AE5" />Nutrition</span>
            <span style={{ fontSize: 22, fontWeight: 700 }}>{kcal.eaten.toLocaleString()} <span className="small muted" style={{ fontWeight: 500 }}>{kcal.target ? `/ ${kcal.target.toLocaleString()} kcal` : 'kcal'}</span></span>
            <span className="small muted">Protein {kcal.protein} g{kcal.proteinTarget ? ` of ${kcal.proteinTarget} g` : ''}</span>
          </a>
        )}
        {conn?.status === 'connected' && (
          <a href="#/recovery" className="card" style={{ color: 'inherit' }}>
            <span className="row small muted" style={{ fontWeight: 600 }}><Icon name="moon" size={16} color="#1D6AE5" />Recovery</span>
            {recovery ? <span className="small">{recovery}</span> : <span className="small muted">No check-in today</span>}
            <span className="tiny muted">Manual entry (sleep is not available from Health Connect in this app)</span>
          </a>
        )}
      </div>

      {recent && (
        <a href="#/progress" className="card row" style={{ color: 'inherit' }}>
          <div className="icon-box sm"><Icon name="chart" size={18} /></div>
          <div className="col grow"><b style={{ fontSize: 14 }}>Latest personal record</b><span className="small muted">{recent}</span></div>
          <Icon name="chevron" size={18} color="#475569" />
        </a>
      )}

      <a href="#/coach" className="card row" style={{ color: 'inherit' }}>
        <div className="icon-box sm"><Icon name="sparkle" size={18} /></div>
        <div className="col grow"><b style={{ fontSize: 14 }}>AI coach and weekly review</b><span className="small muted">Ask questions or review your week from your logged data</span></div>
        <Icon name="chevron" size={18} color="#475569" />
      </a>

      <div className="row small muted">
        <Icon name="bell" size={16} />
        <span>{reminders.length ? `${reminders.length} reminder${reminders.length > 1 ? 's' : ''} enabled` : 'No reminders enabled'} · <a href="#/reminders">manage</a></span>
      </div>
      {conn && conn.status !== 'connected' && <span className="tiny muted">No fitness tracker connected · <a href="#/devices">connect Health Connect</a></span>}
    </div>
  );
}
