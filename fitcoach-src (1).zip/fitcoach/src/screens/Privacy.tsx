import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import { TopBar } from '../components/ui';
import { exportCsv, saveTextFile } from '../lib/export';
import { loadAiConfig, setDirectApiKey } from '../ai/gemini';
import { cancelAll } from '../notifications/scheduler';
import { getConnection, type ConnectionState } from '../wearables/healthConnect';
import { navigate } from '../lib/router';

export function PrivacyCentre() {
  const { refresh, toast } = useApp();
  const [conn, setConn] = useState<ConnectionState | null>(null);
  const [aiMode, setAiMode] = useState('off');
  const [counts, setCounts] = useState<Record<string, number>>({});
  useEffect(() => {
    (async () => {
      setConn(await getConnection());
      setAiMode((await loadAiConfig()).mode);
      const all = await repo.exportAll();
      const c: Record<string, number> = {};
      for (const [k, v] of Object.entries(all)) if (!['exercises', 'foods', 'settings'].includes(k)) c[k] = v.length;
      setCounts(c);
    })();
  }, []);

  async function exportJson() {
    const all = await repo.exportAll();
    delete all.exercises; delete all.foods; // built-in content; user data only
    const where = await saveTextFile(`fitcoach-export-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(all, null, 2), 'application/json');
    toast(`Exported to ${where}`);
  }
  async function exportSets() {
    const all = await repo.exportAll();
    await exportCsv('fitcoach-sets.csv', (all.set_logs ?? []).map((r) => ({ logged_at: r.logged_at, exercise_id: r.exercise_id, set_index: r.set_index, weight_kg: r.weight_kg, reps: r.reps, completed: r.completed })));
    await exportCsv('fitcoach-hydration.csv', (all.hydration_entries ?? []).map((r) => ({ date: r.local_date, amount_ml: r.amount_ml, logged_at: r.logged_at, deleted: r.deleted_at ? 1 : 0 })));
    await exportCsv('fitcoach-nutrition.csv', (all.nutrition_entries ?? []).map((r) => ({ date: r.local_date, meal: r.meal, food: r.food_name, grams: r.grams, kcal: r.kcal, protein: r.protein, carbs: r.carbs, fat: r.fat, fibre: r.fibre, source: r.source })));
    toast('CSV files exported');
  }
  async function deleteAll() {
    if (!confirm('Delete ALL your data on this phone? This cannot be undone. Export first if you want a copy.')) return;
    if (!confirm('Really delete everything: profile, programme, workouts, nutrition, hydration, measurements, reminders, synced tracker data and the saved AI key?')) return;
    await cancelAll();
    await setDirectApiKey(null);
    await repo.deleteAllUserData();
    await refresh();
    toast('All data deleted');
    navigate('/onboarding', true);
  }

  return (
    <div className="screen">
      <TopBar title="Privacy and data" backTo="/profile" />
      <div className="card small" style={{ lineHeight: '19px' }}>
        <b>Where your data lives</b>
        <span><b>On this phone (SQLite, app-private storage):</b> everything you enter and log, your programme, measurements, hydration, nutrition, reminders and any tracker data synced from Health Connect.</span>
        <span><b>Sent to a backend:</b> nothing. There is no account and no server for this app.</span>
        <span><b>Sent to the AI service (Gemini), only when you enable it:</b> derived summaries for the question at hand (goal, experience, equipment, this week's adherence, strength trend numbers, hydration/sleep averages). Never your name, date of birth, exact body measurements or raw logs. Current mode: <b>{aiMode}</b>.</span>
        <span><b>Health Connect:</b> {conn?.status === 'connected' ? `connected, categories: ${conn.scopes.join(', ')}, last sync ${conn.lastSyncAt ? new Date(conn.lastSyncAt).toLocaleString() : 'never'}` : 'not connected'}. <a href="#/devices">Manage</a>.</span>
        <span><b>Backups:</b> Android auto-backup is disabled for this app so the database and the saved AI key are not copied to Google Drive. Use Export below for a copy you control.</span>
      </div>
      <div className="card">
        <b style={{ fontSize: 14 }}>Your records</b>
        <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>{Object.entries(counts).filter(([, v]) => v > 0).map(([k, v]) => <span key={k} className="pill grey">{k.replace(/_/g, ' ')}: {v}</span>)}</div>
        <button className="btn secondary md" onClick={exportJson}>Export everything (JSON)</button>
        <button className="btn secondary md" onClick={exportSets}>Export sets, hydration and nutrition (CSV)</button>
        <span className="tiny muted">Restore: there is no automatic restore in this version. Keep the JSON export; a future version can import it. Re-entering key values (weight, PRs) is the fallback.</span>
      </div>
      <div className="card">
        <b style={{ fontSize: 14 }}>Delete</b>
        <span className="small muted">Removes all user data from this phone and the saved AI key, cancels notifications, and keeps only the built-in exercise and food library. Health Connect permissions themselves are revoked in the Health Connect app.</span>
        <button className="btn danger md" style={{ border: '1px solid var(--bad-fg)' }} onClick={deleteAll}>Delete all my data</button>
      </div>
    </div>
  );
}
