import { useEffect, useState } from 'react';
import * as repo from '../db/repos';
import type { Exercise } from '../db/types';
import { Icon, TopBar } from '../components/ui';
import { explainExercise, type CoachAnswer } from '../ai/coach';
import { useApp } from '../app/store';
import { isAllowed } from '../engine/programme';

export function ExerciseLibrary() {
  const { profile } = useApp();
  const [all, setAll] = useState<Exercise[]>([]);
  const [q, setQ] = useState('');
  const [pattern, setPattern] = useState<string>('all');
  const [onlyMine, setOnlyMine] = useState(false);
  useEffect(() => { void repo.listExercises().then(setAll); }, []);
  const patterns = ['all', ...new Set(all.map((e) => e.movementPattern))];
  const list = all.filter((e) => (pattern === 'all' || e.movementPattern === pattern) && (!onlyMine || isAllowed(e, profile)) && (q === '' || e.name.toLowerCase().includes(q.toLowerCase()) || e.primaryMuscles.some((m) => m.includes(q.toLowerCase()))));
  return (
    <div className="screen">
      <TopBar title="Exercise library" backTo="/workouts" sub={`${all.length} exercises · text instructions drafted from standard coaching practice; no videos are bundled`} />
      <input className="input" aria-label="Search exercises" placeholder="Search by name or muscle" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="row" style={{ overflowX: 'auto', gap: 6, paddingBottom: 4 }}>
        {patterns.map((p) => <button key={p} className={'pill ' + (pattern === p ? '' : 'grey')} style={{ border: 0, cursor: 'pointer', whiteSpace: 'nowrap', minHeight: 36 }} onClick={() => setPattern(p)}>{p.replace('-', ' ')}</button>)}
      </div>
      <label className="row small"><input type="checkbox" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} /> Only exercises that fit my equipment, level and restrictions</label>
      <div className="stack">
        {list.map((e) => (
          <a key={e.id} href={`#/exercises/${e.id}`} className="card row" style={{ color: 'inherit', padding: '10px 12px' }}>
            <div className="col grow"><b style={{ fontSize: 14 }}>{e.name}</b><span className="tiny muted">{e.primaryMuscles.join(', ')} · {e.equipment.join(' + ')} · {e.difficulty}</span></div>
            <Icon name="chevron" size={18} color="#475569" />
          </a>
        ))}
      </div>
    </div>
  );
}

export function ExerciseDetail({ id, query }: { id: string; query: URLSearchParams }) {
  const [e, setE] = useState<Exercise | null>(null);
  const [subs, setSubs] = useState<Exercise[]>([]);
  const [ai, setAi] = useState<CoachAnswer | null>(null);
  const [busy, setBusy] = useState(false);
  const [prs, setPrs] = useState<string>('');
  useEffect(() => {
    (async () => {
      const ex = await repo.getExercise(id);
      setE(ex);
      if (ex) {
        const m = await repo.getExercisesByIds([...ex.substitutions, ex.easierVariation, ex.harderVariation].filter((x): x is string => !!x));
        setSubs([...m.values()]);
        const p = await repo.listPersonalRecords(ex.id);
        if (p.length) setPrs(p.slice(0, 3).map((x) => x.type === 'best-e1rm' ? `est. 1RM ${x.value} kg` : `${x.weightKg} kg × ${x.reps}`).join(' · '));
      }
    })();
  }, [id]);
  if (!e) return <div className="screen"><TopBar title="Exercise" /><div className="empty">Loading…</div></div>;
  const from = query.get('from');
  return (
    <div className="screen">
      <TopBar title={e.name} backTo={from === 'session' || from === 'workout' ? undefined : '/exercises'} />
      <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
        {e.primaryMuscles.map((m) => <span key={m} className="pill">{m}</span>)}
        {e.secondaryMuscles.map((m) => <span key={m} className="pill grey">{m}</span>)}
        <span className="pill grey">{e.difficulty}</span><span className="pill grey">{e.equipment.join(' + ')}</span>
      </div>
      <div className="card flat" style={{ alignItems: 'center', padding: 24, borderStyle: 'dashed' }} role="img" aria-label="No demonstration media bundled">
        <Icon name="info" color="#475569" />
        <span className="small muted" style={{ textAlign: 'center' }}>No demonstration video or image is bundled. Instructions below are text, drafted from standard strength-and-conditioning coaching practice ({e.reviewStatus}). No trainer endorsement is claimed.</span>
      </div>
      {prs && <div className="card soft small"><b>Your records:</b> {prs}</div>}
      <div className="card"><b>Setup</b><ol className="small" style={{ margin: 0, paddingLeft: 18, lineHeight: '19px' }}>{e.setup.map((s, i) => <li key={i}>{s}</li>)}</ol></div>
      <div className="card"><b>Execution</b><ol className="small" style={{ margin: 0, paddingLeft: 18, lineHeight: '19px' }}>{e.execution.map((s, i) => <li key={i}>{s}</li>)}</ol><span className="small muted">Breathing: {e.breathing}</span></div>
      <div className="card"><b>Dose</b><span className="small">{e.repRange[1] ? `${e.defaultSets} sets × ${e.repRange[0]}–${e.repRange[1]} reps, rest ${e.restSeconds} s` : `${e.defaultSets} × ${e.durationMinutes} min, rest ${e.restSeconds} s`}</span></div>
      <div className="card"><b>Common mistakes</b><ul className="small" style={{ margin: 0, paddingLeft: 18, lineHeight: '19px' }}>{e.mistakes.map((s, i) => <li key={i}>{s}</li>)}</ul></div>
      <div className="card"><b>Safety</b><ul className="small" style={{ margin: 0, paddingLeft: 18, lineHeight: '19px' }}>{e.safety.map((s, i) => <li key={i}>{s}</li>)}</ul>{e.contraindications.length > 0 && <span className="tiny muted">Loads: {e.contraindications.join(', ')}. Skipped automatically if these are in your restrictions.</span>}</div>
      {subs.length > 0 && <div className="card"><b>Variations and substitutes</b>{subs.map((s) => <a key={s.id} href={`#/exercises/${s.id}`} className="row small" style={{ color: 'inherit' }}><span className="grow">{s.name}</span><span className="tiny muted">{s.id === e.easierVariation ? 'easier' : s.id === e.harderVariation ? 'harder' : 'substitute'}</span><Icon name="chevron" size={16} color="#475569" /></a>)}</div>}
      <div className="card">
        <div className="row between"><b>Ask the coach</b>{!ai && <button className="btn secondary sm" disabled={busy} onClick={async () => { setBusy(true); setAi(await explainExercise(e, null)); setBusy(false); }}>{busy ? '…' : 'Explain with AI'}</button>}</div>
        {ai && <p className="small" style={{ whiteSpace: 'pre-wrap', lineHeight: '19px' }}>{ai.text}</p>}
        {ai?.note && <span className="tiny muted">{ai.note}</span>}
      </div>
    </div>
  );
}
