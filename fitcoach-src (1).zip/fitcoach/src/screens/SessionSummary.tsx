import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import { reportFor, type SessionReport } from '../app/services';
import { Icon, TopBar } from '../components/ui';
import { sessionSummary, type CoachAnswer } from '../ai/coach';
import { navigate } from '../lib/router';

export function SessionSummary({ id }: { id?: string }) {
  const { profile, goal } = useApp();
  const [r, setR] = useState<SessionReport | null>(null);
  const [prev, setPrev] = useState<Record<string, string>>({});
  const [ai, setAi] = useState<CoachAnswer | null>(null);
  const [aiBusy, setAiBusy] = useState(false);

  useEffect(() => {
    (async () => {
      if (!id) return;
      const rep = await reportFor(id);
      setR(rep);
      if (!rep) return;
      const p: Record<string, string> = {};
      for (const e of rep.exercises) {
        const last = await repo.lastPerformance(e.exerciseId, id);
        if (last.length) p[e.exerciseId] = last.map((s) => `${s.weightKg ? s.weightKg + '×' : ''}${s.reps}`).join(', ');
      }
      setPrev(p);
    })();
  }, [id]);

  if (!r) return <div className="screen no-tabs"><TopBar title="Summary" backTo="/workouts" /><div className="empty">Loading…</div></div>;
  const s = r.session;
  const dur = s.durationS ? Math.round(s.durationS / 60) : 0;

  async function askAi() {
    setAiBusy(true);
    const summary = { name: s.name, durationMin: dur, setsDone: r!.totalDoneSets, setsPlanned: r!.totalPlannedSets, volumeKg: r!.volumeKg, rpe: s.rpe,
      exercises: r!.exercises.map((e) => ({ name: e.name, sets: e.sets.map((x) => `${x.weightKg}kg x ${x.reps}`), skipped: e.skipped, pain: e.painReported, previous: prev[e.exerciseId] ?? null })),
      records: r!.newRecords };
    setAi(await sessionSummary(summary, profile, goal));
    setAiBusy(false);
  }

  return (
    <div className="screen no-tabs">
      <TopBar title={s.status === 'completed' ? 'Workout logged' : 'Session ended early'} backTo="/workouts" sub={`${s.name} · ${new Date(s.startedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}`} />
      <div className="grid3">
        <div className="card stat"><b>{dur} min</b><span className="tiny muted">Duration</span></div>
        <div className="card stat"><b>{r.totalDoneSets} / {r.totalPlannedSets}</b><span className="tiny muted">Sets done</span></div>
        <div className="card stat"><b>{r.volumeKg.toLocaleString()} kg</b><span className="tiny muted">Volume</span></div>
      </div>
      {r.newRecords.length > 0 && (
        <div className="card soft">
          <div className="row"><Icon name="sparkle" color="#1D6AE5" /><b>New personal record{r.newRecords.length > 1 ? 's' : ''}</b></div>
          {r.newRecords.map((p, i) => (
            <span key={i} className="small">{p.exerciseName}: {p.type === 'heaviest' ? `heaviest load ${p.weightKg} kg × ${p.reps}` : p.type === 'best-e1rm' ? `estimated 1RM ≈ ${p.value} kg (estimate from ${p.weightKg} kg × ${p.reps})` : `most reps at ${p.weightKg} kg: ${p.reps}`}</span>
          ))}
        </div>
      )}
      <div className="card">
        <b>Planned vs completed</b>
        {r.exercises.map((e) => (
          <div key={e.exerciseId + e.name} className="row" style={{ alignItems: 'flex-start' }}>
            <span style={{ width: 10, height: 10, borderRadius: 5, marginTop: 5, flexShrink: 0, background: e.done >= e.planned ? 'var(--blue)' : '#fff', border: '2px solid var(--blue)', boxSizing: 'border-box' }} />
            <div className="col grow">
              <b style={{ fontSize: 13 }}>{e.name}{e.substitutedFrom ? <span className="tiny muted"> (swapped in)</span> : ''}</b>
              <span className="tiny muted">{e.sets.length ? e.sets.map((x) => `${x.weightKg ? x.weightKg + ' × ' : ''}${x.reps}`).join(', ') : e.skipped ? 'skipped' : 'no sets logged'}{prev[e.exerciseId] ? ` · last time ${prev[e.exerciseId]}` : ''}{e.painReported ? ' · pain reported' : ''}</span>
            </div>
            <span className={'pill ' + (e.done >= e.planned ? '' : 'warn')}>{e.done}/{e.planned}</span>
          </div>
        ))}
        {s.rpe != null && <span className="small muted">Reported effort {s.rpe}/10{s.notes ? ` · ${s.notes}` : ''}</span>}
        <span className="tiny muted">Difficulty feedback shapes next week's suggestions; loads never jump automatically.</span>
      </div>
      <div className="card">
        <div className="row between"><b>Coach summary</b>{!ai && <button className="btn secondary sm" disabled={aiBusy} onClick={askAi}>{aiBusy ? 'Thinking…' : 'Ask AI coach'}</button>}</div>
        {ai && ai.text && <p className="small" style={{ whiteSpace: 'pre-wrap', lineHeight: '19px' }}>{ai.text}</p>}
        {ai && ai.source === 'fallback' && <span className="tiny muted">{ai.note}</span>}
        {!ai && <span className="small muted">Optional. Uses Gemini with only this session's numbers; works when online and configured.</span>}
      </div>
      <div className="row">
        <button className="btn secondary md" onClick={() => navigate('/progress')}>Progress</button>
        <button className="btn md" onClick={() => navigate('/')}>Back to home</button>
      </div>
    </div>
  );
}
