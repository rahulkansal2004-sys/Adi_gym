import { useEffect, useState } from 'react';
import { useApp } from '../app/store';
import * as repo from '../db/repos';
import type { Food, NutritionEntry } from '../db/types';
import { Icon, Ring, Sheet, TopBar } from '../components/ui';
import { calorieTarget } from '../engine/targets';
import { addDays, localDate, uid } from '../lib/time';

type Meal = NutritionEntry['meal'];
const MEALS: Meal[] = ['breakfast', 'lunch', 'snack', 'dinner', 'other'];

export function Nutrition() {
  const { profile, goal, toast } = useApp();
  const [date, setDate] = useState(localDate());
  const [entries, setEntries] = useState<NutritionEntry[]>([]);
  const [sheet, setSheet] = useState<'none' | 'search' | 'manual' | 'edit'>('none');
  const [meal, setMeal] = useState<Meal>('breakfast');
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Food[]>([]);
  const [food, setFood] = useState<Food | null>(null);
  const [grams, setGrams] = useState(100);
  const [manual, setManual] = useState({ name: '', kcal: '', protein: '', carbs: '', fat: '', fibre: '' });
  const [editing, setEditing] = useState<NutritionEntry | null>(null);
  const [recent, setRecent] = useState<Food[]>([]);
  const target = goal ? calorieTarget(profile, goal.primaryGoal) : null;
  const vegOnly = profile.diet === 'vegetarian' || profile.diet === 'vegan';

  const reload = async () => {
    setEntries(await repo.listNutrition(date));
    const yesterday = await repo.listNutrition(addDays(date, -1));
    const ids = [...new Set([...(await repo.listNutrition(date)), ...yesterday].map((e) => e.foodId).filter((x): x is string => !!x))].slice(0, 6);
    const foods: Food[] = [];
    for (const id of ids) { const f = await repo.getFood(id); if (f) foods.push(f); }
    setRecent(foods);
  };
  useEffect(() => { void reload(); }, [date]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (sheet !== 'search') return;
    const t = setTimeout(async () => setResults(await repo.searchFoods(q, vegOnly)), 150);
    return () => clearTimeout(t);
  }, [q, sheet, vegOnly]);

  const tot = entries.reduce((a, e) => ({ kcal: a.kcal + e.kcal, protein: a.protein + e.protein, carbs: a.carbs + e.carbs, fat: a.fat + e.fat, fibre: a.fibre + e.fibre }), { kcal: 0, protein: 0, carbs: 0, fat: 0, fibre: 0 });

  function macrosFor(f: Food, g: number) {
    const k = g / 100;
    return { kcal: r1(f.per100g.kcal * k), protein: r1(f.per100g.protein * k), carbs: r1(f.per100g.carbs * k), fat: r1(f.per100g.fat * k), fibre: r1(f.per100g.fibre * k) };
  }

  async function addFood() {
    if (!food) return;
    const m = macrosFor(food, grams);
    await repo.addNutritionEntry({ meal, foodId: food.id, foodName: food.name, grams, ...m, source: food.source === 'label' ? 'label' : 'database', localDate: date });
    setSheet('none'); setFood(null); setQ('');
    await reload(); toast(`Added ${food.name}`);
  }

  async function addManual() {
    if (!manual.name || !manual.kcal) { toast('Name and calories are required'); return; }
    await repo.addNutritionEntry({ meal, foodId: null, foodName: manual.name, grams: 0, kcal: Number(manual.kcal) || 0, protein: Number(manual.protein) || 0, carbs: Number(manual.carbs) || 0, fat: Number(manual.fat) || 0, fibre: Number(manual.fibre) || 0, source: 'manual', localDate: date });
    if (confirm('Save this as a reusable custom food?')) {
      await repo.addCustomFood({ id: 'custom-' + uid(), name: manual.name, category: 'meal', vegetarian: vegOnly, servings: [{ label: '1 serving', grams: 100 }], per100g: { kcal: Number(manual.kcal) || 0, protein: Number(manual.protein) || 0, carbs: Number(manual.carbs) || 0, fat: Number(manual.fat) || 0, fibre: Number(manual.fibre) || 0 }, source: 'estimate', isCustom: true });
    }
    setSheet('none'); setManual({ name: '', kcal: '', protein: '', carbs: '', fat: '', fibre: '' });
    await reload();
  }

  async function saveEdit() {
    if (!editing) return;
    await repo.updateNutritionEntry(editing);
    setSheet('none'); setEditing(null);
    await reload();
  }

  if (!profile.nutritionEnabled) {
    return (
      <div className="screen">
        <h1>Nutrition</h1>
        <div className="card"><b>Nutrition tracking is off</b><span className="small muted">Turn it on in Profile to log meals with the Indian food database.</span><a href="#/edit-profile/preferences" className="btn md">Open preferences</a></div>
      </div>
    );
  }

  return (
    <div className="screen">
      <TopBar title="Nutrition" sub={`${date === localDate() ? 'Today' : date} · ${profile.diet}`} right={<button className="btn sm" onClick={() => { setQ(''); setSheet('search'); }}>Add food</button>} />
      <div className="row">
        <button className="icon-btn" aria-label="Previous day" onClick={() => setDate(addDays(date, -1))}><Icon name="back" /></button>
        <input className="input grow" type="date" aria-label="Date" value={date} max={localDate()} onChange={(e) => setDate(e.target.value)} />
        <button className="icon-btn" aria-label="Next day" disabled={date >= localDate()} onClick={() => setDate(addDays(date, 1))}><Icon name="chevron" /></button>
      </div>
      <div className="card row" style={{ gap: 16 }}>
        <Ring value={tot.kcal} max={target?.kcal ?? Math.max(tot.kcal, 1)} label={`${Math.round(tot.kcal)} of ${target?.kcal ?? 'unknown'} kilocalories`} center={String(Math.round(tot.kcal))} sub={target ? `of ${target.kcal} kcal` : 'kcal'} size={110} />
        <div className="col grow" style={{ gap: 8 }}>
          {([['Protein', tot.protein, target?.protein], ['Carbs', tot.carbs, target?.carbs], ['Fat', tot.fat, target?.fat], ['Fibre', tot.fibre, target?.fibre]] as const).map(([n, v, t]) => (
            <div key={n} className="col" style={{ gap: 3 }}>
              <div className="row between small"><span className="muted">{n}</span><b>{Math.round(v)}{t ? ` / ${t}` : ''} g</b></div>
              <div className="progress"><div style={{ width: `${t ? Math.min(100, (v / t) * 100) : 0}%` }} /></div>
            </div>
          ))}
        </div>
      </div>
      {!target && <span className="tiny muted">Add date of birth, height and weight in Profile for calorie and protein targets.</span>}
      {target && <span className="tiny muted">{target.note}</span>}
      <div className="row between"><b>Meals</b><span className="tiny muted">Source: label · database · manual</span></div>
      {MEALS.map((m) => {
        const list = entries.filter((e) => e.meal === m);
        if (list.length === 0 && m === 'other') return null;
        return (
          <div key={m} className="card" style={{ gap: 6 }}>
            <div className="row between"><b style={{ textTransform: 'capitalize', fontSize: 14 }}>{m}</b><span className="small muted">{Math.round(list.reduce((a, e) => a + e.kcal, 0))} kcal</span></div>
            {list.length === 0 && <button className="btn ghost sm" style={{ justifyContent: 'flex-start', padding: 0 }} onClick={() => { setMeal(m); setQ(''); setSheet('search'); }}>+ Add to {m}</button>}
            {list.map((e) => (
              <button key={e.id} className="list-item" style={{ background: 'none', border: 0, borderTop: '1px solid #F1F5F9', width: '100%', textAlign: 'left', cursor: 'pointer', padding: '8px 0' }} onClick={() => { setEditing({ ...e }); setSheet('edit'); }}>
                <div className="col grow"><span style={{ fontSize: 14, fontWeight: 600 }}>{e.foodName}</span><span className="tiny muted">{e.grams ? `${e.grams} g · ` : ''}P {Math.round(e.protein)} · C {Math.round(e.carbs)} · F {Math.round(e.fat)} · fibre {Math.round(e.fibre)} g</span></div>
                <div className="col" style={{ alignItems: 'flex-end' }}><b style={{ fontSize: 13 }}>{Math.round(e.kcal)} kcal</b><span className={'pill ' + (e.source === 'label' ? 'good' : e.source === 'manual' ? 'warn' : '')} style={{ fontSize: 10, padding: '2px 6px' }}>{e.source}</span></div>
              </button>
            ))}
          </div>
        );
      })}
      <span className="tiny muted">Targets are general guidance from your goal and activity, not medical advice. No extreme deficits are suggested (minimum 1400 kcal).</span>

      <Sheet open={sheet === 'search'} onClose={() => { setSheet('none'); setFood(null); }} title={food ? food.name : 'Add food'}>
        {!food ? (
          <>
            <div className="grid5">{MEALS.map((m) => <button key={m} className={'choice' + (meal === m ? ' on' : '')} style={{ minHeight: 36, fontSize: 12, padding: 0 }} aria-pressed={meal === m} onClick={() => setMeal(m)}>{m}</button>)}</div>
            <input className="input" aria-label="Search foods" placeholder="Search: roti, dal, paneer, poha, whey…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
            {q === '' && recent.length > 0 && <><span className="small muted">Recent</span><div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>{recent.map((f) => <button key={f.id} className="pill" style={{ border: 0, cursor: 'pointer' }} onClick={() => { setFood(f); setGrams(f.servings[0]?.grams ?? 100); }}>{f.name}</button>)}</div></>}
            <div className="stack" style={{ maxHeight: '45vh', overflow: 'auto' }}>
              {results.map((f) => (
                <button key={f.id} className="card row" style={{ border: 0, textAlign: 'left', cursor: 'pointer', padding: '10px 12px' }} onClick={() => { setFood(f); setGrams(f.servings[0]?.grams ?? 100); }}>
                  <div className="col grow"><b style={{ fontSize: 14 }}>{f.name}{f.isCustom ? ' (custom)' : ''}</b><span className="tiny muted">{f.per100g.kcal} kcal · {f.per100g.protein} g protein per 100 g · {f.source === 'label' ? 'label' : f.source === 'estimate' ? 'estimate' : 'database (IFCT approx.)'}</span></div>
                  {!f.vegetarian && <span className="pill warn" style={{ fontSize: 10 }}>non-veg</span>}
                </button>
              ))}
              {results.length === 0 && q && <div className="empty">No match. Add it manually below.</div>}
            </div>
            <button className="btn secondary md" onClick={() => setSheet('manual')}>Enter nutrition manually</button>
          </>
        ) : (
          <>
            <span className="small muted">{food.notes ?? ''} Source: {food.source === 'label' ? 'product label' : food.source === 'estimate' ? 'estimate for a mixed dish' : 'database estimate (approximate IFCT values)'}.</span>
            <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>
              {food.servings.map((s) => <button key={s.label} className={'choice' + (grams === s.grams ? ' on' : '')} style={{ minHeight: 38, fontSize: 13 }} aria-pressed={grams === s.grams} onClick={() => setGrams(s.grams)}>{s.label} ({s.grams} g)</button>)}
            </div>
            <div className="field"><label htmlFor="g">Quantity (g)</label><input id="g" className="input" type="number" inputMode="decimal" value={grams} onChange={(e) => setGrams(Number(e.target.value) || 0)} /></div>
            <div className="card flat small">{(() => { const m = macrosFor(food, grams); return `${m.kcal} kcal · protein ${m.protein} g · carbs ${m.carbs} g · fat ${m.fat} g · fibre ${m.fibre} g`; })()}</div>
            <div className="row"><button className="btn secondary md" onClick={() => setFood(null)}>Back</button><button className="btn md" onClick={addFood}>Add to {meal}</button></div>
          </>
        )}
      </Sheet>

      <Sheet open={sheet === 'manual'} onClose={() => setSheet('none')} title="Manual entry">
        <input className="input" aria-label="Food name" placeholder="Name" value={manual.name} onChange={(e) => setManual({ ...manual, name: e.target.value })} />
        <div className="grid3">
          {(['kcal', 'protein', 'carbs', 'fat', 'fibre'] as const).map((k) => <div key={k} className="field"><label htmlFor={'m' + k}>{k}{k === 'kcal' ? '' : ' (g)'}</label><input id={'m' + k} className="input" type="number" inputMode="decimal" value={manual[k]} onChange={(e) => setManual({ ...manual, [k]: e.target.value })} /></div>)}
        </div>
        <button className="btn" onClick={addManual}>Add to {meal}</button>
      </Sheet>

      <Sheet open={sheet === 'edit' && !!editing} onClose={() => setSheet('none')} title="Edit entry">
        {editing && (
          <>
            <input className="input" aria-label="Name" value={editing.foodName} onChange={(e) => setEditing({ ...editing, foodName: e.target.value })} />
            <div className="grid5">{MEALS.map((m) => <button key={m} className={'choice' + (editing.meal === m ? ' on' : '')} style={{ minHeight: 36, fontSize: 12, padding: 0 }} onClick={() => setEditing({ ...editing, meal: m })}>{m}</button>)}</div>
            <div className="grid3">
              {(['kcal', 'protein', 'carbs', 'fat', 'fibre'] as const).map((k) => <div key={k} className="field"><label htmlFor={'e' + k}>{k}</label><input id={'e' + k} className="input" type="number" inputMode="decimal" value={editing[k]} onChange={(e) => setEditing({ ...editing, [k]: Number(e.target.value) || 0, source: 'manual' })} /></div>)}
            </div>
            <span className="tiny muted">Editing values marks the entry as manually corrected.</span>
            <div className="row"><button className="btn danger md" onClick={async () => { await repo.deleteNutritionEntry(editing.id); setSheet('none'); await reload(); }}>Delete</button><button className="btn md" onClick={saveEdit}>Save</button></div>
          </>
        )}
      </Sheet>
    </div>
  );
}

function r1(n: number): number { return Math.round(n * 10) / 10; }
