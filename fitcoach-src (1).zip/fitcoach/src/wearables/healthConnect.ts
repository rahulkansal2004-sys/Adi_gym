// Android Health Connect integration through the `capacitor-health` plugin.
// Only categories the plugin can actually read are offered: daily steps, active calories, recorded
// workouts and weight records. Sleep and resting heart rate are NOT available through this plugin
// and are shown as "not available" rather than estimated. Samsung Health, Google Fit and most
// Android wearable apps write into Health Connect, so they arrive through this path.
import { Capacitor } from '@capacitor/core';
import { Health, type HealthPermission } from 'capacitor-health';
import { db } from '../db';
import { nowIso, uid, addDays, localDate } from '../lib/time';

export type Category = 'steps' | 'active-calories' | 'workouts' | 'weight';

export const CATEGORY_INFO: Record<Category, { label: string; permission: HealthPermission; unit: string }> = {
  steps: { label: 'Daily steps', permission: 'READ_STEPS', unit: 'count' },
  'active-calories': { label: 'Active calories', permission: 'READ_ACTIVE_CALORIES', unit: 'kcal' },
  workouts: { label: 'Recorded workouts', permission: 'READ_WORKOUTS', unit: 'min' },
  weight: { label: 'Weight readings', permission: 'READ_WEIGHT', unit: 'kg' },
};

export const UNAVAILABLE_CATEGORIES = ['Sleep duration and stages', 'Resting heart rate', 'Heart-rate zones'];

export interface ConnectionState {
  provider: 'health-connect';
  available: boolean; // Health Connect app installed and platform native
  status: 'not-connected' | 'connected' | 'error';
  scopes: Category[];
  lastSyncAt: string | null;
  lastError: string | null;
}

export async function getConnection(): Promise<ConnectionState> {
  const row = (await db().query(`SELECT * FROM wearable_connections WHERE provider = 'health-connect'`))[0];
  let available = false;
  if (Capacitor.isNativePlatform()) {
    try { available = (await Health.isHealthAvailable()).available; } catch { available = false; }
  }
  return {
    provider: 'health-connect', available,
    status: (row?.status as ConnectionState['status']) ?? 'not-connected',
    scopes: row ? (JSON.parse(row.scopes_json as string) as Category[]) : [],
    lastSyncAt: (row?.last_sync_at as string) ?? null, lastError: (row?.last_error as string) ?? null,
  };
}

async function saveConnection(patch: Partial<{ status: string; scopes: Category[]; lastSyncAt: string | null; lastError: string | null }>): Promise<void> {
  const cur = await getConnection();
  const status = patch.status ?? cur.status;
  const scopes = patch.scopes ?? cur.scopes;
  await db().run(
    `INSERT INTO wearable_connections(provider, status, scopes_json, last_sync_at, last_error, connected_at) VALUES('health-connect',?,?,?,?,?)
     ON CONFLICT(provider) DO UPDATE SET status=excluded.status, scopes_json=excluded.scopes_json, last_sync_at=excluded.last_sync_at, last_error=excluded.last_error`,
    [status, JSON.stringify(scopes), patch.lastSyncAt === undefined ? cur.lastSyncAt : patch.lastSyncAt,
      patch.lastError === undefined ? cur.lastError : patch.lastError, cur.status === 'connected' ? null : nowIso()],
  );
}

/** Ask Health Connect for the chosen categories. Returns the categories actually granted. */
export async function connect(categories: Category[]): Promise<{ granted: Category[]; denied: Category[] }> {
  if (!Capacitor.isNativePlatform()) throw new Error('Health Connect is only available in the Android app.');
  const perms = categories.map((c) => CATEGORY_INFO[c].permission);
  const res = await Health.requestHealthPermissions({ permissions: perms });
  const grantedPerms = new Set<string>();
  for (const p of res.permissions) for (const [k, v] of Object.entries(p)) if (v) grantedPerms.add(k);
  const granted = categories.filter((c) => grantedPerms.has(CATEGORY_INFO[c].permission));
  const denied = categories.filter((c) => !grantedPerms.has(CATEGORY_INFO[c].permission));
  await saveConnection({ status: granted.length ? 'connected' : 'not-connected', scopes: granted, lastError: denied.length ? `Not granted: ${denied.map((d) => CATEGORY_INFO[d].label).join(', ')}` : null });
  return { granted, denied };
}

export async function disconnect(): Promise<void> {
  await db().batch([
    { sql: `DELETE FROM wearable_samples WHERE provider = 'health-connect'` },
    { sql: `DELETE FROM wearable_connections WHERE provider = 'health-connect'` },
  ]);
  // Health Connect permissions are revoked by the user in the Health Connect app; open it for them.
  try { await Health.openHealthConnectSettings(); } catch { /* not native */ }
}

/** Incremental sync: fetch from the last sync (minus 2 days for late-arriving data) up to now, dedupe by (type, start, source). */
export async function sync(daysBack = 30): Promise<{ records: number; error: string | null }> {
  const conn = await getConnection();
  if (conn.status !== 'connected') return { records: 0, error: 'Not connected' };
  const historyId = uid();
  const started = nowIso();
  await db().run(`INSERT INTO sync_history(id, provider, started_at, status) VALUES(?, 'health-connect', ?, 'running')`, [historyId, started]);
  const from = conn.lastSyncAt ? new Date(new Date(conn.lastSyncAt).getTime() - 2 * 86400000) : new Date(Date.now() - daysBack * 86400000);
  const startDate = from.toISOString();
  const endDate = new Date().toISOString();
  let records = 0;
  try {
    const stmts: { sql: string; params: (string | number | null)[] }[] = [];
    const up = (type: string, value: number, unit: string, start: string, end: string, sourceId: string) => {
      stmts.push({
        sql: `INSERT INTO wearable_samples(id, provider, type, value, unit, start_at, end_at, source_id, synced_at) VALUES(?, 'health-connect', ?, ?, ?, ?, ?, ?, ?)
              ON CONFLICT(provider, type, start_at, source_id) DO UPDATE SET value = excluded.value, end_at = excluded.end_at, synced_at = excluded.synced_at`,
        params: [uid(), type, value, unit, start, end, sourceId, endDate],
      });
      records++;
    };
    if (conn.scopes.includes('steps')) {
      const r = await Health.queryAggregated({ startDate, endDate, dataType: 'steps', bucket: 'day' });
      for (const s of r.aggregatedData) up('steps', s.value, 'count', s.startDate, s.endDate, 'aggregate');
    }
    if (conn.scopes.includes('active-calories')) {
      const r = await Health.queryAggregated({ startDate, endDate, dataType: 'active-calories', bucket: 'day' });
      for (const s of r.aggregatedData) up('active-calories', s.value, 'kcal', s.startDate, s.endDate, 'aggregate');
    }
    if (conn.scopes.includes('workouts')) {
      const r = await Health.queryWorkouts({ startDate, endDate, includeHeartRate: false, includeRoute: false, includeSteps: false });
      for (const w of r.workouts) up('workout', Math.round((w.duration ?? 0) / 60), 'min', w.startDate, w.endDate, `${w.sourceBundleId ?? 'unknown'}:${w.workoutType ?? 'workout'}:${w.id ?? ''}`);
    }
    if (conn.scopes.includes('weight')) {
      const r = await Health.queryRecords({ startDate, endDate, dataType: 'weight' });
      for (const w of r.records) up('weight', w.value, 'kg', w.startDate, w.endDate, w.sourceBundleId ?? 'unknown');
    }
    if (stmts.length) await db().batch(stmts);
    await saveConnection({ lastSyncAt: endDate, lastError: null });
    await db().run(`UPDATE sync_history SET finished_at=?, status='ok', records=? WHERE id=?`, [nowIso(), records, historyId]);
    return { records, error: null };
  } catch (e) {
    const msg = (e as Error).message;
    await saveConnection({ status: /permission|denied|not granted/i.test(msg) ? 'error' : 'connected', lastError: msg });
    await db().run(`UPDATE sync_history SET finished_at=?, status='error', error=? WHERE id=?`, [nowIso(), msg, historyId]);
    return { records, error: msg };
  }
}

export interface DaySummary { date: string; steps: number | null; activeKcal: number | null; workoutMinutes: number | null }

/** Per-day tracker data for the dashboard; null where nothing was synced (never estimated). */
export async function daySummaries(days = 7): Promise<DaySummary[]> {
  const to = localDate();
  const fromDate = addDays(to, -(days - 1));
  const rows = await db().query<{ type: string; value: number; start_at: string }>(
    `SELECT type, value, start_at FROM wearable_samples WHERE provider = 'health-connect' AND substr(start_at, 1, 10) BETWEEN ? AND ?`, [fromDate, to],
  );
  const out = new Map<string, DaySummary>();
  for (let i = 0; i < days; i++) { const d = addDays(fromDate, i); out.set(d, { date: d, steps: null, activeKcal: null, workoutMinutes: null }); }
  for (const r of rows) {
    const d = localDate(new Date(r.start_at));
    const s = out.get(d);
    if (!s) continue;
    if (r.type === 'steps') s.steps = (s.steps ?? 0) + r.value;
    if (r.type === 'active-calories') s.activeKcal = (s.activeKcal ?? 0) + r.value;
    if (r.type === 'workout') s.workoutMinutes = (s.workoutMinutes ?? 0) + r.value;
  }
  return [...out.values()];
}

export async function syncHistory(limit = 10): Promise<{ startedAt: string; status: string; records: number; error: string | null }[]> {
  const rows = await db().query(`SELECT * FROM sync_history ORDER BY started_at DESC LIMIT ?`, [limit]);
  return rows.map((r) => ({ startedAt: r.started_at as string, status: r.status as string, records: r.records as number, error: (r.error as string) ?? null }));
}
