# FitCoach — offline-first personal fitness coach for Android

A personal-use Android app (Capacitor + React/TypeScript + native SQLite) that builds a 12-week training
programme from your goal, guides each workout set by set, tracks hydration, nutrition (Indian food
database), body measurements and recovery, reminds you with local notifications, reads steps and
workouts from Android Health Connect, and uses Gemini for coaching when the phone is online.

No account. No cloud database. No backend required. All data lives in SQLite on the phone.

## Project structure

```
fitcoach/
├── src/
│   ├── main.tsx                 boot: opens native SQLite (Android) or sql.js (browser preview), runs migrations + seed
│   ├── app/                     App.tsx (hash router + screens), store.tsx (profile/goal/programme context), services.ts
│   ├── db/                      schema.ts (migrations), driver.ts, native.ts (Android SQLite), sqljs.ts (preview/tests), repos.ts, types.ts
│   ├── data/                    exercises.ts (92 exercises), foods.ts (145 foods, Indian-first)
│   ├── engine/                  programme.ts (generator), progression.ts (double progression, PRs, e1RM),
│   │                            substitution.ts (+ symptom triage), schedule.ts (reschedule/shorten), review.ts (weekly review), targets.ts
│   ├── ai/                      gemini.ts (off / proxy / direct modes, caps, validation), coach.ts (prompts + deterministic fallbacks)
│   ├── notifications/           planner.ts (pure scheduling, quiet hours, dedupe), scheduler.ts (@capacitor/local-notifications)
│   ├── wearables/               healthConnect.ts (capacitor-health: steps, active kcal, workouts, weight; dedupe + sync history)
│   ├── screens/                 Onboarding, Home, Workouts, WorkoutPreview, ActiveSession, SessionSummary, Progress, Nutrition,
│   │                            Hydration, Measurements, Recovery, Coach, WeeklyReview, Reschedule, Exercises, Profile, EditProfile,
│   │                            Reminders, Devices, Privacy, ImproveApp
│   ├── components/ui.tsx        icons, tab bar, sheet, ring, line/bar charts, stepper
│   └── styles.css               design tokens from the design canvas (blue #1D6AE5 on white, Inter)
├── android/                     Capacitor Android project (manifest with Health Connect + notification permissions, backups disabled)
├── gemini-proxy/                server.mjs: zero-dependency proxy that keeps GEMINI_API_KEY on your computer
├── tests/                       vitest unit tests (db, engines, notifications) + Playwright e2e smoke test (tests/e2e/smoke.mjs)
├── docs/                        ARCHITECTURE.md, GEMINI.md, WEARABLES.md, BUILD-AND-INSTALL.md, FEATURE-MATRIX.md, TEST-REPORT.md
├── scripts/build-apk.sh         one-command local APK build
└── .github/workflows/android-apk.yml   free APK build on GitHub Actions
```

## Quick start

```bash
npm ci                 # install
npm test               # 35 unit tests (sql.js in memory)
npm run build          # type-check + Vite production build
npm run dev            # browser preview at http://localhost:5173 (sql.js persisted to IndexedDB; Android uses native SQLite)
```

Build the APK (needs Android SDK; see `docs/BUILD-AND-INSTALL.md` for the three ways to get one):

```bash
./scripts/build-apk.sh
# -> android/app/build/outputs/apk/debug/app-debug.apk
```

## Gemini

The APK contains no API key. Read `docs/GEMINI.md`: run `gemini-proxy/server.mjs` on your computer (recommended),
or type the key into Settings › AI coach (stored in the app's private storage, with the trade-off explained there).

## Environment variables

The app itself needs none. The proxy reads `gemini-proxy/.env` (`GEMINI_API_KEY`, optional `PROXY_TOKEN`, `PORT`).
See `gemini-proxy/.env.example`.

## Status

Honest feature matrix: `docs/FEATURE-MATRIX.md`. Test results: `docs/TEST-REPORT.md`. Known limitations and next
actions are listed in both.

FitCoach is a fitness tool, not a medical device. It does not diagnose or treat anything.
